import hashlib
import heapq
import json
import math
import sys
from pathlib import Path
import geometry

root = Path(__file__).resolve().parent
case_bytes = (root / 'inputs/forest-full45-medium.json').read_bytes()
report_bytes = (root / 'original-report.json').read_bytes()
case = json.loads(case_bytes)
report = json.loads(report_bytes)
world = case['world']
requests = {value['id']: value for value in case['requests']}
actors = {}
for item in report['FinalState'].split('|'):
    identifier, point, state, goal, target = item.split(':')
    actors[int(identifier)] = {'position': tuple(map(float, point.split(','))), 'state': int(state), 'goal': int(goal), 'target': int(target)}

geometry.world = world
geometry.width = world['width']
geometry.height = world['height']
geometry.size = world['cellSizeMm']
geometry.origin = world['origin']['x'], world['origin']['y']
geometry.rectangles = []
for cell, walk in enumerate(world['walkable']):
    if walk == '0':
        x = geometry.origin[0] + cell % geometry.width * geometry.size
        y = geometry.origin[1] + cell // geometry.width * geometry.size
        geometry.rectangles.append((x, y, x + geometry.size, y + geometry.size))

def configure(identifier):
    geometry.radius = requests[identifier]['radiusMm']
    geometry.others = [(i, value['position'], requests[i]['radiusMm']) for i, value in actors.items() if i != identifier]
    goal = actors[identifier]['goal']
    return (geometry.origin[0] + (goal % geometry.width + .5) * geometry.size,
            geometry.origin[1] + (goal // geometry.width + .5) * geometry.size)

def query(identifier, supplied_path=None):
    goal = configure(identifier)
    start = actors[identifier]['position']
    destination_blockers = [{'id': i, 'gapMm': math.dist(goal, value['position']) - geometry.radius - requests[i]['radiusMm']}
                            for i, value in actors.items() if i != identifier and math.dist(goal, value['position']) < geometry.radius + requests[i]['radiusMm'] - 1e-7]
    base = {'id': identifier, 'start': start, 'goalCell': actors[identifier]['goal'], 'goal': goal,
            'radiusMm': geometry.radius, 'originalProfile': requests[identifier], 'otherBodiesFixed': 44,
            'destinationBlockers': destination_blockers}
    if supplied_path is not None:
        path = [start] + supplied_path + [goal]
        base['suppliedPathLegal'] = all(geometry.clear(a, b) for a, b in zip(path, path[1:]))
        base['legChecks'] = [{'from': a, 'to': b, 'legal': geometry.clear(a, b)} for a, b in zip(path, path[1:])]
    elif destination_blockers:
        base['searchSkipped'] = 'Actual final destination occupied under the fixed-neighbor condition.'
        path = []
    else:
        spacing = 25
        visited = set()
        parents = {}
        costs = {start: 0}
        queue = [(math.dist(start, goal), 0, start)]
        standable = {}
        budget = 30000
        while queue and len(visited) < budget:
            _, cost, point = heapq.heappop(queue)
            if point in visited:
                continue
            visited.add(point)
            if point == goal:
                break
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    if dx == 0 and dy == 0:
                        continue
                    nxt = point[0] + dx * spacing, point[1] + dy * spacing
                    if nxt in visited:
                        continue
                    if nxt not in standable:
                        standable[nxt] = geometry.clear(nxt, nxt)
                    if not standable[nxt] or not geometry.clear(point, nxt):
                        continue
                    candidate = cost + math.dist(point, nxt)
                    if candidate < costs.get(nxt, math.inf):
                        costs[nxt] = candidate
                        parents[nxt] = point
                        heapq.heappush(queue, (candidate + math.dist(nxt, goal), candidate, nxt))
        base.update({'searchSpacingMm': spacing, 'searchBudget': budget, 'expanded': len(visited), 'budgetExhausted': len(visited) >= budget})
        path = []
        if goal in visited:
            point = goal
            while point != start:
                path.append(point)
                point = parents[point]
            path.append(start)
            path.reverse()
            simple = [start]
            index = 0
            while index < len(path) - 1:
                final = len(path) - 1
                while final > index + 1 and not geometry.clear(path[index], path[final]):
                    final -= 1
                simple.append(path[final])
                index = final
            path = simple
    base['witnessFound'] = bool(path) and all(geometry.clear(a, b) for a, b in zip(path, path[1:]))
    base['path'] = path
    if base['witnessFound']:
        base['minimumBodyGapMm'] = min(math.sqrt(geometry.dist2_segment(p, a, b)) - geometry.radius - r
                                       for a, b in zip(path, path[1:]) for _, p, r in geometry.others)
        base['lengthMm'] = sum(math.dist(a, b) for a, b in zip(path, path[1:]))
    return base

if '--actor15' in sys.argv:
    result = query(15)
    (root / 'id15-fine-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    sys.exit(0)

result = {
    'scope': 'Independent original-body fixed-neighbor geometry queries from E4 Forest45 failed state; not candidate execution or a full-case pass.',
    'inputFileSha256': hashlib.sha256(case_bytes).hexdigest(),
    'reportSha256': hashlib.sha256(report_bytes).hexdigest(),
    'canonicalInputSha256': report['InputSha256'],
    'queries': [query(15, [(9150, -4810)]), query(14), query(19)]
}
(root / 'query-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
