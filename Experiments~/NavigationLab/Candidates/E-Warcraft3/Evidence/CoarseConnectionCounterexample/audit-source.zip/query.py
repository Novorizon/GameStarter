import hashlib
import heapq
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT
case_bytes = (ROOT / 'inputs/u-obstacle.json').read_bytes()
case = json.loads(case_bytes)
report_bytes = (ROOT / 'original-report.json').read_bytes()
report = json.loads(report_bytes)
world = case['world']
actors = {}
for item in report['FinalState'].split('|'):
    identifier, point, state, goal, target = item.split(':')
    actors[int(identifier)] = {'position': tuple(map(float, point.split(','))), 'state': int(state), 'goal': int(goal), 'target': int(target)}
requests = {r['id']: r for r in case['requests']}
who = 38
radius = requests[who]['radiusMm']
start = actors[who]['position']
goal_cell = actors[who]['goal']
size = world['cellSizeMm']
width, height = world['width'], world['height']
origin = world['origin']['x'], world['origin']['y']
goal = (origin[0] + (goal_cell % width + .5) * size, origin[1] + (goal_cell // width + .5) * size)
others = [(i, a['position'], requests[i]['radiusMm']) for i, a in actors.items() if i != who]
rectangles = []
for cell, walk in enumerate(world['walkable']):
    if walk == '0':
        x, y = origin[0] + cell % width * size, origin[1] + cell // width * size
        rectangles.append((x, y, x + size, y + size))

def dist2_segment(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = dx * dx + dy * dy
    t = 0 if length == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / length))
    return (p[0] - a[0] - t * dx) ** 2 + (p[1] - a[1] - t * dy) ** 2

def rectangle2(a, b, rect):
    left, bottom, right, top = rect
    low, high = 0, 1
    intersects = True
    for axis, minimum, maximum in [(0, left, right), (1, bottom, top)]:
        delta = b[axis] - a[axis]
        if abs(delta) < 1e-12:
            if not minimum <= a[axis] <= maximum:
                intersects = False
                break
        else:
            one, two = (minimum - a[axis]) / delta, (maximum - a[axis]) / delta
            low, high = max(low, min(one, two)), min(high, max(one, two))
            if low > high:
                intersects = False
                break
    if intersects:
        return 0
    def point_rect(p):
        return max(left - p[0], 0, p[0] - right) ** 2 + max(bottom - p[1], 0, p[1] - top) ** 2
    return min(point_rect(a), point_rect(b), *(dist2_segment(corner, a, b) for corner in [(left, bottom), (right, bottom), (right, top), (left, top)]))

def clear(a, b, stationary=True):
    if min(a[0], b[0]) < origin[0] + radius - 1e-7 or min(a[1], b[1]) < origin[1] + radius - 1e-7:
        return False
    if max(a[0], b[0]) > origin[0] + width * size - radius + 1e-7 or max(a[1], b[1]) > origin[1] + height * size - radius + 1e-7:
        return False
    for target in world['targets']:
        if dist2_segment((target['x'], target['y']), a, b) < (target['radiusMm'] + radius - 1e-7) ** 2:
            return False
    for rect in rectangles:
        if max(a[0], b[0]) + radius < rect[0] or min(a[0], b[0]) - radius > rect[2] or max(a[1], b[1]) + radius < rect[1] or min(a[1], b[1]) - radius > rect[3]:
            continue
        if rectangle2(a, b, rect) < (radius - 1e-7) ** 2:
            return False
    if stationary:
        for _, position, other_radius in others:
            if dist2_segment(position, a, b) < (radius + other_radius - 1e-7) ** 2:
                return False
    return True

start_cell = (int((start[0] - origin[0]) // size), int((start[1] - origin[1]) // size))
connections = []
for dy in range(-1, 2):
    for dx in range(-1, 2):
        x, y = start_cell[0] + dx, start_cell[1] + dy
        p = origin[0] + (x + .5) * size, origin[1] + (y + .5) * size
        if clear(p, p, False) and clear(start, p, False):
            block = [{'id': i, 'gapMm': math.sqrt(dist2_segment(pos, start, p)) - radius - r} for i, pos, r in others if dist2_segment(pos, start, p) < (radius + r - 1e-7) ** 2]
            connections.append({'cell': y * width + x, 'point': p, 'dynamicClear': not block, 'blockers': block})

# This independent path is a feasibility witness, never an input to E's controller.
spacing = 250
points = {start, goal}
for x in range(24500, 36501, spacing):
    for y in range(8500, 22501, spacing):
        p = float(x), float(y)
        if clear(p, p):
            points.add(p)
queue = [(0, start)]
distances = {start: 0}
parents = {}
visited = set()
while queue:
    distance, point = heapq.heappop(queue)
    if point in visited:
        continue
    visited.add(point)
    if point == goal:
        break
    if point == start:
        neighbors = [p for p in points if p != start and math.dist(start, p) <= 1600]
    else:
        neighbors = [(point[0] + dx * spacing, point[1] + dy * spacing) for dx in range(-1, 2) for dy in range(-1, 2) if dx or dy]
    for nxt in neighbors:
        if nxt not in points or nxt in visited or not clear(point, nxt):
            continue
        candidate = distance + math.dist(point, nxt)
        if candidate < distances.get(nxt, math.inf):
            distances[nxt] = candidate
            parents[nxt] = point
            heapq.heappush(queue, (candidate, nxt))
path = []
if goal in visited:
    p = goal
    while p != start:
        path.append(p)
        p = parents[p]
    path.append(start)
    path.reverse()
    # Safe greedy LOS simplification uses the same independent exact geometry.
    simplified = [path[0]]
    i = 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1 and not clear(path[i], path[j]):
            j -= 1
        simplified.append(path[j])
        i = j
    path = simplified

gaps = []
for a, b in zip(path, path[1:]):
    for i, p, r in others:
        gaps.append((math.sqrt(dist2_segment(p, a, b)) - radius - r, i))
result = {
    'caseInputSha256': hashlib.sha256(case_bytes).hexdigest(),
    'reportInputSha256': report['InputSha256'],
    'reportSha256': hashlib.sha256(report_bytes).hexdigest(),
    'actor': who, 'radiusMm': radius, 'start': start, 'goalCell': goal_cell, 'goal': goal,
    'othersFixedAtActualFinalPositions': True,
    'otherBodies': len(others), 'original3x3Connections': connections,
    'original3x3DynamicConnections': sum(c['dynamicClear'] for c in connections),
    'refinedWitnessSpacingMm': spacing, 'refinedNodesExpanded': len(visited),
    'witnessFound': bool(path), 'path': path,
    'pathLengthMm': sum(math.dist(a, b) for a, b in zip(path, path[1:])),
    'minimumBodyGapMmAndId': min(gaps) if gaps else None,
    'scope': 'Independent stationary-neighbor feasibility witness from the actual failed final state; not a successful run of candidate E.'
}
(OUT / 'query-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
