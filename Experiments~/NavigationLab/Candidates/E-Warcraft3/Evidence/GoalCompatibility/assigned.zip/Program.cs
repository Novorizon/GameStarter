using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var factory = (INavigationFactory)Activator.CreateInstance(assembly.GetType(args[1], true)!)!;
const int width = 16;
const int height = 12;
var walk = new bool[width * height];
for (int y = 1; y < height - 1; y++)
{
    for (int x = 1; x < width - 1; x++)
    {
        walk[y * width + x] = true;
    }
}
int a = 11 + 4 * width;
int b = 11 + 5 * width;
int c = 9 + 3 * width;
var holds = new bool[walk.Length];
holds[a] = holds[b] = holds[c] = true;
int firstSpawn = 2 + 4 * width;
int secondSpawn = 2 + 6 * width;
var world = new WorldDefinition(width, height, 1000, new Point2(0, 0), walk, holds, new[] { firstSpawn, secondSpawn },
    new[] { new TargetDefinition(1, new Point2(12500, 5000), 300) }, 10000);
var profile = new UnitProfile(650, 1000, 2500);
var first = new SpawnRequest(1, profile, firstSpawn, 1, a);
var second = new SpawnRequest(2, profile, secondSpawn, 1, b);
using var nav = factory.Create(world, new[] { profile });
var oracle = new ContinuousOracle(world);
var current = nav.Snapshot().ToArray();
Require(nav.TrySpawn(first), "First explicit valid goal rejected.");
var next = nav.Snapshot().ToArray();
oracle.RegisterBirth(first, current, next);
current = next;
bool conflictAccepted = nav.TrySpawn(second);
next = nav.Snapshot().ToArray();
Require(!conflictAccepted, "Conflicting explicit goal incorrectly admitted.");
oracle.VerifyRejectedBirth(current, next);
Require(next.Single().GoalCell == a, "Rejected request modified first assigned goal.");
string reason = nav.LastSpawnFailure;
current = next;
nav.Remove(1);
next = nav.Snapshot().ToArray();
oracle.RegisterDeath(1, current, next);
current = next;
Require(nav.TrySpawn(second), "Original pending request did not admit after explicit death freed the conflict.");
next = nav.Snapshot().ToArray();
oracle.RegisterBirth(second, current, next);
current = next;
Require(current.Single().GoalCell == b, "Candidate changed explicit goal to available alternative C.");
int stable = 0;
int steps = 0;
for (; steps < 10000 && stable < 2000; steps++)
{
    nav.Step();
    next = nav.Snapshot().ToArray();
    oracle.ValidateTransition(current, next, 5);
    stable = next.Single().GoalCell == b && next.Single().State == MotionState.Attacking
        && next.Single().Position == current.Single().Position ? stable + 1 : 0;
    current = next;
}
Require(stable >= 2000, "Re-admitted assigned body failed to settle.");
var result = new
{
    success = true,
    scope = "Supplementary assigned-conflict rejection and explicit-death retry, not common49 or shared3. Alternative C exists but must not replace assigned B.",
    firstAssignedGoal = a,
    secondAssignedGoal = b,
    originalAlternativeGoal = c,
    prescribedGoalPairGapMm = Point2.Distance(world.Center(a), world.Center(b)) - 1300,
    conflictRejected = true,
    rejectionReason = reason,
    explicitDeaths = 1,
    originalSecondRequestReadmitted = true,
    unchangedAssignedGoal = current.Single().GoalCell,
    steps,
    stableMicrosteps = stable,
    candidateAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant()
};
File.WriteAllText(args[2], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(result));
static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
