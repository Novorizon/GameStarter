using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

const string resultRoot = ".";
const int actorId = 38;
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "inputs/u-obstacle.json")));
using var originalReport = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "original-report.json")));

var source = input.RootElement.GetProperty("world");
int width = source.GetProperty("width").GetInt32();
int height = source.GetProperty("height").GetInt32();
int cellSize = source.GetProperty("cellSizeMm").GetInt32();
var origin = source.GetProperty("origin");
var world = new WorldDefinition(
    width,
    height,
    cellSize,
    new Point2(origin.GetProperty("x").GetDouble(), origin.GetProperty("y").GetDouble()),
    source.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    source.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    source.GetProperty("gatheringDistanceMm").GetInt32());
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => value.GetProperty("id").GetInt32(), value => new SpawnRequest(
    value.GetProperty("id").GetInt32(),
    new UnitProfile(value.GetProperty("radiusMm").GetInt32(), value.GetProperty("speedMmPerTick").GetInt32(), value.GetProperty("attackRangeMm").GetInt32()),
    value.GetProperty("spawnCell").GetInt32(),
    value.GetProperty("targetId").GetInt32(),
    value.GetProperty("assignedGoalCell").GetInt32()));
var initial = originalReport.RootElement.GetProperty("FinalState").GetString()!.Split('|').Select(value =>
{
    var parts = value.Split(':');
    var coordinates = parts[1].Split(',');
    return new UnitSnapshot(
        int.Parse(parts[0]),
        new Point2(
            double.Parse(coordinates[0], System.Globalization.CultureInfo.InvariantCulture),
            double.Parse(coordinates[1], System.Globalization.CultureInfo.InvariantCulture)),
        (MotionState)int.Parse(parts[2]),
        int.Parse(parts[3]),
        int.Parse(parts[4]));
}).OrderBy(value => value.Id).ToArray();
var actor = initial.Single(value => value.Id == actorId);
var profile = requests[actorId].Profile;
// Read-only query against the actual frozen candidate DLL, not a copied/rebuilt approximation.
var assembly = typeof(NavigationLab.Candidates.EWarcraft3.WarcraftFactory).Assembly;
var geometryType = assembly.GetType("NavigationLab.Candidates.EWarcraft3.PathingGeometry")!;
var searchType = assembly.GetType("NavigationLab.Candidates.EWarcraft3.GlobalSearch")!;
const BindingFlags internalInstance = BindingFlags.Instance | BindingFlags.NonPublic;
var geometry = Activator.CreateInstance(geometryType, internalInstance, null, new object[] { world }, null)!;
var search = Activator.CreateInstance(searchType, internalInstance, null, new object[] { world, geometry, (Action<string, long>)((_, _) => { }), true }, null)!;
Func<Point2, Point2, bool> dynamicClear = (from, to) => initial.Where(value => value.Id != actorId).All(other =>
    ContinuousOracle.DistanceToSegment(other.Position, from, to) >= profile.RadiusMm + requests[other.Id].Profile.RadiusMm - .001);
var found = searchType.GetMethod("Find", internalInstance)!.Invoke(search, new object[] { actor.Position, actor.GoalCell, profile, dynamicClear, 0 });
var staticFound = searchType.GetMethod("Find", internalInstance)!.Invoke(search, new object[] { actor.Position, actor.GoalCell, profile, null!, 0 });
Require(found is IEnumerable<Point2> && staticFound != null, "Refined dynamic Find must return a path for the exact original failed state.");
var path = new[] { actor.Position }.Concat((IEnumerable<Point2>)found!).ToArray();
Require(path.Length > 1 && path[path.Length - 1] == world.Center(actor.GoalCell), "Refined search changed the original goal.");
var connectionResult = searchType.GetMethod("Connections", internalInstance)!.Invoke(search, new object[] { actor.Position, profile.RadiusMm });
var connections = ((IEnumerable<int>)connectionResult!).ToArray();
Require(
    connections.Length == 8 && connections.All(cell => !dynamicClear(actor.Position, world.Center(cell))),
    "Expected all eight legal static connectors to be dynamically blocked.");

// Seed the independently validated original failed state. This does not pretend to replay candidate history or original births.
var oracle = new ContinuousOracle(world);
var live = (Dictionary<int, SpawnRequest>)typeof(ContinuousOracle).GetField("live", internalInstance)!.GetValue(oracle)!;
foreach (var value in initial)
{
    live.Add(value.Id, requests[value.Id]);
}
oracle.ValidateTransition(initial, initial, 0);
var current = initial;
int microsteps = 0;
double distanceMoved = 0;
var replayStates = new List<object>();
for (int segment = 1; segment < path.Length; segment++)
{
    Point2 destination = path[segment];
    while (Point2.Distance(current.Single(value => value.Id == actorId).Position, destination) > 1e-7)
    {
        Point2 from = current.Single(value => value.Id == actorId).Position;
        Point2 vector = destination - from;
        double distance = Math.Min(vector.Length, profile.SpeedMmPerTick / (double)SimulationProtocol.Substeps);
        Point2 to = from + vector.Normalized * distance;
        var next = current.Select(value => ReplaceActor(value, actorId, to, MotionState.Moving)).ToArray();
        oracle.ValidateTransition(current, next, SimulationProtocol.MicrostepMilliseconds);
        current = next;
        distanceMoved += distance;
        microsteps++;
        replayStates.Add(new { microstep = microsteps, x = to.X, y = to.Y, state = 0 });
    }
}
var final = current.Select(value => ReplaceActor(value, actorId, value.Position, MotionState.Waiting)).ToArray();
oracle.ValidateTransition(current, final, 0);
for (int hold = 0; hold < 200 * SimulationProtocol.Substeps; hold++)
{
    oracle.ValidateTransition(final, final, SimulationProtocol.MicrostepMilliseconds);
}
Require(
    final.All(value => value.State != MotionState.Moving) && final.Count(value => value.State == MotionState.Attacking) == 16,
    "Witness did not complete 16 attack + 40 wait.");
var result = new
{
    success = true,
    scope = "Refined algorithm-produced path from E1b's actual failed state; all 55 other bodies remain fixed. "
        + "Not a replay of the original birth history or a full live navigator execution.",
    refinedCandidateDynamicFindReturnedPath = found != null,
    frozenCandidateStaticFindReturnedPath = staticFound != null,
    staticConnectors = connections,
    dynamicConnectorCount = connections.Count(cell => dynamicClear(actor.Position, world.Center(cell))),
    inputFileSha256 = FileHash(Path.Combine(resultRoot, "inputs/u-obstacle.json")),
    originalCaseReportSha256 = FileHash(Path.Combine(resultRoot, "original-report.json")),
    originalCaseCanonicalInputSha256 = originalReport.RootElement.GetProperty("InputSha256").GetString(),
    candidateAssemblySha256 = FileHash(assembly.Location),
    coreAssemblySha256 = FileHash(typeof(Point2).Assembly.Location),
    oracleAssemblySha256 = FileHash(typeof(ContinuousOracle).Assembly.Location),
    originalBodyRadiusMm = profile.RadiusMm,
    originalSpeedMmPer50ms = profile.SpeedMmPerTick,
    preservedGoal = actor.GoalCell,
    otherBodyCount = initial.Length - 1,
    movementMicrosteps = microsteps,
    movementMilliseconds = microsteps * SimulationProtocol.MicrostepMilliseconds,
    movedDistanceMm = distanceMoved,
    holdLogicalTicks = 200,
    holdDriftMm = 0,
    totalValidatedBodySweeps = oracle.BodySweeps,
    totalValidatedPairSweeps = oracle.PairSweeps,
    minimumBodyGapMm = oracle.MinimumBodyGapMm,
    maximumObservedStepMm = oracle.MaximumObservedStepMm,
    finalAttack = final.Count(value => value.State == MotionState.Attacking),
    finalWait = final.Count(value => value.State == MotionState.Waiting),
    scriptSha256 = FileHash("Program.cs"),
    algorithmPath = path.Select(point => new { x = point.X, y = point.Y }).ToArray()
};
File.WriteAllText("replay-states.json", JsonSerializer.Serialize(replayStates, new JsonSerializerOptions { WriteIndented = true }) + "\n");
File.WriteAllText("replay-result.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));

static string FileHash(string name) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(name))).ToLowerInvariant();

static UnitSnapshot ReplaceActor(UnitSnapshot value, int id, Point2 position, MotionState state)
{
    return value.Id == id ? new UnitSnapshot(id, position, state, value.GoalCell, value.TargetId) : value;
}

static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
