# B：ORCA、动态重寻路与路线简化

B 分支从冻结 A `8c0dd50` 分离。这里只增加独立候选和实验，不替换正式战斗或 SDK。

## 实际实现

- **B0 / `NavigationLab.Candidates.BOrca.OrcaFactory`**：官方 RVO2-CS ORCA 速度求解器，八邻 A* 全局路线，实际停止身体参与动态重寻路，精确静态扫掠和停止身体约束下的可见路点简化。
- **B1 / `NavigationLab.Candidates.BOrca.OrcaYieldFactory`**：B0 加显式临时让位、到位者返场、死亡后的空攻击位补员，以及受限射程单位的合法目标交换。B1 的结果单独报告，不覆盖 B0 的失败。

路线节点为原格边长的一半，支持身体通过偶数宽走廊的中线。**最终站位仍只允许原世界的 holding cell**；路线节点不会增加最终目标数，也不修改地图、单位身体或速度。

目标由当前世界、实际请求和可用目标动态计算。没有读取旧72人的见证路线、预分配目标或成功次序，也没有调用 A 的 SIPP 代码。统一 Runner 可以提供显式目标测试，此时保留请求的目标身份。

每次 Step 是5ms；配置速度仍使用mm/50ms。ORCA 时域2秒、障碍时域0.5秒、邻居上限256，邻域至少5米或12倍本体半径。实际 ORCA 半径等于请求身体半径，没有沿用旧1m实验的20mm永久膨胀，避免把Forest的500mm相切终点人为改成无解。

## 实际物理执行

ORCA 给出下一微步提议后，候选的连续非穿透执行器检查障碍、基地、速度和双方相对运动。发现不安全提议时，本微步保持相关身体的原位置并将速度置零；双方停止采用闭包迭代，避免前车停止后后车继续穿入。

`UnsafeStaticOrSpeedProposalStops` 和 `UnsafePairProposalStops` 记录这些提议。最终运动仍由**不同实现的共享 Oracle**逐5ms验证，不能把提议过滤说成原ORCA求解器从未产生碰撞风险。执行器只会停止或减速，不寻找额外路径、不瞬移、不挤小身体；无法继续前进仍会作为到达超时失败保留。

状态除目标距离外还检查实际射程/视线或实际候场半径；持有 Goal 不等于身体已经到位。基础实现首轮在候场外边界提前约1mm标记Waiting的问题已保留为开发失败并修正，不计为“ORCA不适用”的证明。

## 官方代码与标准库适配

上游为 [官方 RVO2-CS](https://github.com/snape/RVO2-CS/tree/de124a275d51d421bb9e2a77952210527ab60b04)，固定提交 `de124a275d51d421bb9e2a77952210527ab60b04`，Apache-2.0。`ThirdParty/upstream.json` 记录所有原字节 SHA，许可证及版权头保留。上游源码未修改。

上游的近期BCL参数校验API不属于netstandard2.1。新增的 `ArgumentGuardCompatibility.cs` 在RVO命名空间提供等价int/float校验，抛出实际 `System.ArgumentOutOfRangeException`；这不改变有效参数下的速度求解器。候选目标为netstandard2.1/C#9，Runner为.NET8；Unity/IL2CPP结论分别以对应实际运行报告为准。

上游 Agent/KdTree 硬编码 `Simulator.Instance`，且 `_instance` 是静态只读字段。`SimulatorContext` 在共享锁内切换完整实例字段，调用结束后保留本battle状态并恢复host字段；第三方文件仍保持原字节。NumWorkers=1、DoStep同步结束后才恢复。它提供**串行交错隔离**，不宣称每个battle有可并行独立的原生模拟器或同一个navigator可以并发调用。

死亡和动态地形变化会重建本battle的RVO索引，保留其余身体的真实位置、速度和请求ID。自检比较单独执行与插入另一battle Step/出生/死亡时的全轨迹，并验证回调实际变更后抛异常仍恢复host、局部battle实际变更不丢失。

## 构建与执行

共享 Core/Oracle/Runner 同步后，在本分支根目录：

```bash
dotnet build Experiments~/NavigationLab/Candidates/B-Orca/NavigationLab.BOrca.csproj -c Release -m:1

dotnet run --project Experiments~/NavigationLab/Runner/NavigationLab.Runner.csproj -c Release -- \
  --assembly Experiments~/NavigationLab/Candidates/B-Orca/bin/Release/netstandard2.1/NavigationLab.BOrca.dll \
  --factory NavigationLab.Candidates.BOrca.OrcaFactory --suite full --output Artifacts/NavigationLab/B0

dotnet run --project Experiments~/NavigationLab/Runner/NavigationLab.Runner.csproj -c Release -- \
  --assembly Experiments~/NavigationLab/Candidates/B-Orca/bin/Release/netstandard2.1/NavigationLab.BOrca.dll \
  --factory NavigationLab.Candidates.BOrca.OrcaYieldFactory --suite full --output Artifacts/NavigationLab/B1

dotnet run --project Experiments~/NavigationLab/Candidates/B-Orca/SelfTest/NavigationLab.BOrca.SelfTest.csproj -c Release
```

开发时 Core/Oracle 可以用 `NavigationLabCoreRoot`、`NavigationLabOracleRoot` MSBuild属性指向协调工作树；发布分支使用仓库内部相对路径。通过、失败、不支持、原始队列和身份守恒由共享 Runner 报告。有限矩阵只说明已执行输入上的表现，不构成对任意多单位场景的完备性证明。
