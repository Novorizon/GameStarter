using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.Candidates.BOrca;

var flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var walk = new bool[24 * 9];
for (int x = 0; x < 24; x++)
{
    walk[4 * 24 + x] = true;
    if (x >= 16)
    {
        for (int y = 1; y < 8; y++)
        {
            walk[y * 24 + x] = true;
        }
    }
}
int goalCell = 4 * 24 + 18;
int spawnCell = 4 * 24 + 1;
var holding = new bool[walk.Length];
holding[goalCell] = true;
var world = new WorldDefinition(24, 9, 500, new Point2(0, -60), walk, holding, new[] { spawnCell }, new[]
{
    new TargetDefinition(1, new Point2(10750, 2190), 500)
}, 4000);
var profile = new UnitProfile(250, 55, 1000);
var factory = new OrcaFactory();
using var navigator = factory.Create(world, new[] { profile });
var oracle = new ContinuousOracle(world);
var beforeBirth = navigator.Snapshot().ToArray();
var command = new SpawnRequest(1, profile, spawnCell, 1, goalCell);
if (!navigator.TrySpawn(command))
{
    throw new Exception("Original regression fixture could not admit its request.");
}
oracle.RegisterBirth(command, beforeBirth, navigator.Snapshot());
var before = navigator.Snapshot().ToArray();
navigator.Step();
var after = navigator.Snapshot().ToArray();
oracle.ValidateTransition(before, after, 5);
Point2 actual = after.Single().Position;
Point2 goal = world.Center(goalCell);
var candidateAssembly = typeof(OrcaFactory).Assembly;
var routeType = candidateAssembly.GetType("NavigationLab.Candidates.BOrca.RouteMesh", true)!;
var mesh = Activator.CreateInstance(routeType, flags, null, new object[] { world, 250d }, null)!;
int join = (int)routeType.GetMethod("ClosestJoin", flags)!.Invoke(mesh, new object?[] { actual, null, null })!;
object?[] findArguments = { actual, goal, null, 0, null, int.MaxValue };
var path = routeType.GetMethod("Find", flags)!.Invoke(mesh, findArguments);
var geometryType = candidateAssembly.GetType("NavigationLab.Candidates.BOrca.Geometry", true)!;
bool Clear(double tolerance) => (bool)geometryType.GetMethod("Clear", flags)!.Invoke(null, new object[] { world, actual, goal, 250d, true, tolerance })!;
bool oracleSegment = ContinuousOracle.SegmentFits(world, actual, goal, profile.RadiusMm);
if (actual.Y == world.Center(spawnCell).Y || !oracleSegment || join != -1 || path != null || Clear(0) || !Clear(.025))
{
    throw new Exception("Expected precision mismatch was not reproduced.");
}
// This additional empty change is a separate diagnostic, not part of the original regression fixture.
var emptyChange = new WorldChange();
var beforeChange = navigator.Snapshot().ToArray();
bool changed = navigator.ApplyWorldChange(emptyChange);
var afterChange = navigator.Snapshot().ToArray();
if (!changed)
{
    throw new Exception("Empty change unexpectedly rejected.");
}
oracle.ApplyChange(emptyChange, beforeChange, afterChange);
navigator.Step();
var afterNextStep = navigator.Snapshot().ToArray();
oracle.ValidateTransition(afterChange, afterNextStep, 5);
double nextMovement = Point2.Distance(afterChange.Single().Position, afterNextStep.Single().Position);
Console.WriteLine(JsonSerializer.Serialize(new
{
    scope = "Exact original offset-corridor fixture, one real frozen-B0 Step and a local RouteMesh query. No complete-case failure or universal navigation conclusion.",
    factory = factory.Id,
    candidateAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(candidateAssembly.Location))).ToLowerInvariant(),
    coreAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Point2).Assembly.Location))).ToLowerInvariant(),
    oracleAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(ContinuousOracle).Assembly.Location))).ToLowerInvariant(),
    originalSpawnCell = spawnCell, originalGoalCell = goalCell, radiusMm = profile.RadiusMm, speedMmPer50Ms = profile.SpeedMmPerTick,
    realAfterFirstStep = new[] { actual.X, actual.Y },
    mathematicalCentrelineY = world.Center(spawnCell).Y,
    observedCentrelineErrorMm = actual.Y - world.Center(spawnCell).Y,
    sharedOracleSegmentFits = oracleSegment, candidateZeroToleranceClear = Clear(0), candidateExistingExecutionToleranceClear = Clear(.025),
    closestJoin = join, findReturnedNull = path == null, expanded = findArguments[3],
    additionalEmptyWorldChange = new { accepted = changed, exactBodyPositionPreserved = afterChange.Single().Position == actual, nextMovementMm = nextMovement,
        note = "The existing direct-goal preference still moves after path clearing here. Therefore null Find does not prove this straight fixture freezes or fails to arrive." },
    checkedBodySweeps = oracle.BodySweeps, checkedPairSweeps = oracle.PairSweeps
}, new JsonSerializerOptions { WriteIndented = true }));
