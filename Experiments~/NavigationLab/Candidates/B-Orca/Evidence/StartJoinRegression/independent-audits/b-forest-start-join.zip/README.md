# B1 actual Forest009 endpoint precision check

The completed `b1-forest-009-dev/forest-full44-large.json` failure used candidate DLL `e75fd5c5a1603f92c89028d66fc1f9a177b55b9ae55ba83567b5d7725ff81b1b`, identical to the frozen B1 candidate queried here. The original development run did not request fresh replay; this audit retains that scope and does not treat it as a final comparison report.

At all **44 original actual final body positions**, the original shared static Oracle and candidate Geometry.Clear with **zero tolerance** both accept the unchanged radius and world. The number of denied endpoints is **zero**. Therefore the proven offset-corridor local join precision mismatch is not demonstrated at this Forest failure's final positions and cannot be used here as an established explanation for failure or for blocked negotiated yield.

This is a negative result about those exact endpoints. It does not inspect every historical frame, all path joins, or every yield request, and it does not prove that the entire Forest failure is caused by ORCA's mathematical formulation. No simulation, original report, candidate source, radius, target, world or criterion was changed.

Program.cs reconstructs the world and profiles from the original exported input and reads coordinates and goals directly from the original FinalState. The candidate DLL hash is checked against that original completed development summary. Snapshot contains the exact query DLLs and relevant source for review; source-build-manifest.json preserves build metadata. manifest.json binds all copied files and the original input, summary and case report. Large traces are not copied.
