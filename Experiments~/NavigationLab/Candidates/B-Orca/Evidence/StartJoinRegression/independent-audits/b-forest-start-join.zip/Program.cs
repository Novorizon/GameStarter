using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.Candidates.BOrca;

string source = "/workspace/navigation-comparison/results/b1-forest-009-dev";
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(source, "inputs/forest-full44-large.json")));
using var caseResult = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(source, "forest-full44-large.json")));
using var summary = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(source, "summary.json")));
var w = input.RootElement.GetProperty("world");
var world = new WorldDefinition(
    w.GetProperty("width").GetInt32(),
    w.GetProperty("height").GetInt32(),
    w.GetProperty("cellSizeMm").GetInt32(),
    new Point2(w.GetProperty("origin").GetProperty("x").GetDouble(), w.GetProperty("origin").GetProperty("y").GetDouble()),
    w.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    w.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    w.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    w.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    w.GetProperty("gatheringDistanceMm").GetInt32());
var profiles = input.RootElement.GetProperty("requests").EnumerateArray()
    .ToDictionary(value => value.GetProperty("id").GetInt32(), value => value.GetProperty("radiusMm").GetInt32());
var assembly = typeof(OrcaFactory).Assembly;
string dllHash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant();
if (dllHash != summary.RootElement.GetProperty("candidateAssemblySha256").GetString())
{
    throw new Exception("Query DLL does not match original completed development failure.");
}
var flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
var geometry = assembly.GetType("NavigationLab.Candidates.BOrca.Geometry", true)!;
var meshType = assembly.GetType("NavigationLab.Candidates.BOrca.RouteMesh", true)!;
var affected = new List<object>();
int checkedBodies = 0;
int totalDenied = 0;
foreach (string body in caseResult.RootElement.GetProperty("FinalState").GetString()!.Split('|'))
{
    var parts = body.Split(':');
    int id = int.Parse(parts[0]);
    var xy = parts[1].Split(',');
    var position = new Point2(double.Parse(xy[0], System.Globalization.CultureInfo.InvariantCulture), double.Parse(xy[1], System.Globalization.CultureInfo.InvariantCulture));
    int state = int.Parse(parts[2]);
    int goal = int.Parse(parts[3]);
    int radius = profiles[id];
    bool oracle = ContinuousOracle.SegmentFits(world, position, position, radius);
    bool Clear(double tolerance) => (bool)geometry.GetMethod("Clear", flags)!.Invoke(null, new object[] { world, position, position, (double)radius, true, tolerance })!;
    if (!oracle)
    {
        throw new Exception("Original reported position is not accepted by its shared oracle: " + id);
    }
    checkedBodies++;
    if (Clear(0))
    {
        continue;
    }
    totalDenied++;
    var mesh = Activator.CreateInstance(meshType, flags, null, new object[] { world, (double)radius }, null)!;
    int join = (int)meshType.GetMethod("ClosestJoin", flags)!.Invoke(mesh, new object?[] { position, null, null })!;
    object?[] query = { position, world.Center(goal), null, 0, null, int.MaxValue };
    bool nullPath = meshType.GetMethod("Find", flags)!.Invoke(mesh, query) == null;
    affected.Add(new
    {
        id, radiusMm = radius, position = new[] { position.X, position.Y }, reportedState = state, goalCell = goal,
        sharedOracleCircleFits = oracle, candidateZeroToleranceClear = false, candidateExistingExecutionToleranceClear = Clear(.025),
        closestJoin = join, findReturnedNull = nullPath, expanded = query[3],
        arrivedAccordingToReport = state != 0
    });
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    scope = "Read-only static queries at original actual positions from a completed B1 no-replay development failure, using the identical candidate DLL. No claim of complete-run root cause or guaranteed correction.",
    candidateAssemblySha256 = dllHash,
    coreAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Point2).Assembly.Location))).ToLowerInvariant(),
    oracleAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(ContinuousOracle).Assembly.Location))).ToLowerInvariant(),
    inputSha256 = caseResult.RootElement.GetProperty("InputSha256").GetString(),
    sourceCaseStatus = caseResult.RootElement.GetProperty("Status").GetString(),
    sourceFinalTick = caseResult.RootElement.GetProperty("FinalTick").GetInt32(),
    sourceReplayRequested = summary.RootElement.GetProperty("replayRequested").GetBoolean(),
    checkedBodies, totalDenied, affected
}, new JsonSerializerOptions { WriteIndented = true }));
