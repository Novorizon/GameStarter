# B start-join / bounded epsilon correction: matched local evidence

The same explicit U fixture was observed under both exact candidates with the same9000-microstep limit, actual shared Core/Oracle binaries, unchanged radius/speed/world/goal/event, and strict full2000-interval (10000ms),<=0.1mm position hold. No shared49 input or deadline changes.

Old817 remains Moving in both modes at9000: the no-change control progresses slowly around the first corner; the empty-change run remains near the start with a null join. This is a finite observation, not a permanent-impossibility claim.

Selectedebda reaches the original goal and completes strict hold in7146/7149 microsteps. Independent re-reading of the final2001 physical snapshots in each trace confirms exactly10000ms and maximum anchor drift0.000057220459mm. Both variants begin at the identical actual float point after their first Step. The old original7000 traces match exactly within the matched old9000 traces despite the shared-role binary build-metadata change.

Earlier artifacts are not silently promoted: the discardedfe6 phase had an overbroad controller and a state-only scratch hold label; the selected7000 window had correct hold flags false because only9.27/9.255seconds remained. Those facts remain in their own folders. This matched check uses the corrected physical hold definition, the same observation window for both sides, and no source/criterion edits.

The selected algorithm includes an explicitly disclosed project epsilon proposal only when raw float integration did not advance, bounded by existing0.025mm and original speed, followed by unchanged static/pair filtering. It does not prove why the solver stopped and is not claimed to be the raw ORCA output or a general convergence guarantee.
