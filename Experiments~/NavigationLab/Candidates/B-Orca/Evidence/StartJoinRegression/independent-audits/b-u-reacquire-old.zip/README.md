# Old frozen B0: U-corridor route-reacquisition regression

This independent scratch regression uses the exact old frozen B0 DLL `8175992a5d009fe91ee8e6707feabc1e3f7a69c04ad3242315f06e54d5da36b7` and its original Core/shared Oracle. No candidate source, execution tolerance, shared acceptance criterion, physical radius or speed was changed. This explicit new regression is not one of the published shared49 cases and does not establish the root cause of the Forest44 failure.

The fixture is 24x14, cell500, origin `(0,-60)`. Row4 and row10 have x1..18 open; column18 connects y4..10. Radius250, speed55 mm/50 ms, spawn100 `(2250,2190)`, assigned goal244 `(2250,5190)`, target `(750,5190)` radius500. Only the original goal is a holding location. The independent shared Oracle verifies the three complete segments `[spawn,(9250,2190),(9250,5190),goal]`. These witness points are never supplied to the navigator.

Both runs use a fresh candidate instance and the exact same fixture. The changed run applies an empty WorldChange after the first real Step; this clears the internal path while the independent Oracle verifies that no physical body position changes.

Observed old-DLL results after 7000 actual 5 ms steps per run:

- With the empty change, the actual first point is `(2255.500078201294,2190.000057220459)`. Local ClosestJoin is -1 and Find is null. The unit remains near the starting point `(2250.0648498535156,2190.000057220459)`, Moving, with 4643 exact zero-displacement steps.
- The no-change control also does **not** complete the full U. It advances to the first turn `(9249.985694885254,2193.1560039520264)`, remains Moving, and has zero exact zero-displacement steps. Therefore this must not be represented as “control PASS versus changed FAIL” or proof that the join mismatch is the only full-route defect.
- All actual per-step body sweeps pass the unchanged shared Oracle. The control has 7001 body checks, the changed run 7002; there is one physical body and no pair sweeps.

The two gzip traces and original output preserve the actual progress difference and the additional corner execution boundary. A correction to the local start join can be tested against this same fixture without pretending that the old control already passed it.

Reproduce with `DOTNET_PROCESSOR_COUNT=1 dotnet run --project Query.csproj -c Release -- /absolute/output/directory`. The original invocation accidentally forwarded `--nologo` as the output argument; its generated trace files were moved back into this audit directory after completion. That affected only their storage path, not the world, candidate, steps, events or Oracle checks. No source or test data was changed to repair the result.
