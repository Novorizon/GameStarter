# Matched9000 U regression: old817

This is one half of a matched before/after local regression, with the exact same U world, request, radius250, speed55, target, empty-change timing,9000-step observation limit and strict hold criteria. A PASS requires2000 complete5ms intervals from a physical position anchor, drift<=0.1mm, with the unchanged actual shared Oracle checking every motion and API event.

Both candidates use the identical actual Core/Oracle binaries copied from the selected local query roles. Core/Contracts.cs and Oracle/ContinuousOracle.cs were also checked byte-identical to the old frozen source before this test. role-binding.json records the exact roles; the old original7000 trajectory was subsequently compared and found exactly preserved in the first7000 frames of this matched old run.

The9000 window applies to both variants. It changes no shared49 input, physical condition or deadline. These explicit local regressions are separate from final shared49 evidence. See ../b-u-precision-comparison/comparison.json for independent trace-level confirmation and the exact before/after result. Original7000 windows and discardedfe6 phase remain separate.

Reproduce: DOTNET_PROCESSOR_COUNT=1 dotnet run --project Query.csproj -c Release -- /absolute/output/directory. Program.cs alone is compiled, referencing the exact Snapshot binaries. Witness polyline is checked by the Oracle, never supplied to the candidate.
