using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.Candidates.BOrca;

int width = 24;
int height = 14;
var walk = new bool[width * height];
for (int x = 1; x <= 18; x++)
{
    walk[4 * width + x] = true;
    walk[10 * width + x] = true;
}
for (int y = 4; y <= 10; y++)
{
    walk[y * width + 18] = true;
}
int spawn = 4 * width + 4;
int goal = 10 * width + 4;
var holding = new bool[walk.Length];
holding[goal] = true;
var world = new WorldDefinition(width, height, 500, new Point2(0, -60), walk, holding, new[] { spawn }, new[]
{
    new TargetDefinition(1, new Point2(750, 5190), 500)
}, 4000);
var profile = new UnitProfile(250, 55, 1000);
var witness = new[] { world.Center(spawn), new Point2(9250, 2190), new Point2(9250, 5190), world.Center(goal) };
for (int leg = 0; leg + 1 < witness.Length; leg++)
{
    if (!ContinuousOracle.SegmentFits(world, witness[leg], witness[leg + 1], profile.RadiusMm))
    {
        throw new Exception("Independent input certificate failed at leg " + leg);
    }
}
string output = Path.GetFullPath(args[0]);
Directory.CreateDirectory(output);
var flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var assembly = typeof(OrcaFactory).Assembly;
var meshType = assembly.GetType("NavigationLab.Candidates.BOrca.RouteMesh", true)!;
object Run(bool clearPath)
{
    var factory = new OrcaFactory();
    using var navigator = factory.Create(world, new[] { profile });
    var oracle = new ContinuousOracle(world);
    using var compressed = new GZipStream(File.Create(Path.Combine(output, clearPath ? "empty-change.jsonl.gz" : "original-path.jsonl.gz")), CompressionLevel.Optimal);
    using var trace = new StreamWriter(compressed, new UTF8Encoding(false));
    var before = navigator.Snapshot().ToArray();
    var request = new SpawnRequest(1, profile, spawn, 1, goal);
    if (!navigator.TrySpawn(request))
    {
        throw new Exception("Original feasible U fixture rejected its spawn.");
    }
    oracle.RegisterBirth(request, before, navigator.Snapshot());
    int stable = 0;
    int stopped = 0;
    Point2? holdAnchor = null;
    double holdMaximumDriftMm = 0;
    int executed = 0;
    int? joinAfterChange = null;
    bool? nullPathAfterChange = null;
    double[]? firstActual = null;
    for (int microstep = 0; microstep < 9000 && stable < 2000; microstep++)
    {
        before = navigator.Snapshot().ToArray();
        navigator.Step();
        var snapshot = navigator.Snapshot().ToArray();
        oracle.ValidateTransition(before, snapshot, 5);
        executed++;
        if (snapshot.Single().Position == before.Single().Position)
        {
            stopped++;
        }
        var unit = snapshot.Single();
        trace.WriteLine(JsonSerializer.Serialize(new { microstep, x = unit.Position.X, y = unit.Position.Y, state = unit.State.ToString(), goal = unit.GoalCell }));
        if (unit.State != MotionState.Attacking)
        {
            stable = 0;
            holdAnchor = null;
        }
        else if (!holdAnchor.HasValue || Point2.Distance(holdAnchor.Value, unit.Position) > SimulationProtocol.GeometryToleranceMm)
        {
            holdAnchor = unit.Position;
            stable = 0;
            holdMaximumDriftMm = 0;
        }
        else
        {
            stable++;
            holdMaximumDriftMm = Math.Max(holdMaximumDriftMm, Point2.Distance(holdAnchor.Value, unit.Position));
        }
        if (microstep == 0)
        {
            firstActual = new[] { unit.Position.X, unit.Position.Y };
            if (clearPath)
            {
                var change = new WorldChange();
                bool accepted = navigator.ApplyWorldChange(change);
                var afterChange = navigator.Snapshot().ToArray();
                if (!accepted || unit.Position != afterChange.Single().Position)
                {
                    throw new Exception("Empty change changed actual position or was rejected.");
                }
                oracle.ApplyChange(change, snapshot, afterChange);
                var mesh = Activator.CreateInstance(meshType, flags, null, new object[] { world, 250d }, null)!;
                joinAfterChange = (int)meshType.GetMethod("ClosestJoin", flags)!.Invoke(mesh, new object?[] { unit.Position, null, null })!;
                object?[] query = { unit.Position, world.Center(goal), null, 0, null, int.MaxValue };
                nullPathAfterChange = meshType.GetMethod("Find", flags)!.Invoke(mesh, query) == null;
                trace.WriteLine(JsonSerializer.Serialize(new { microstep, kind = "empty-world-change", accepted, sameActualPosition = true, joinAfterChange, nullPathAfterChange }));
            }
        }
    }
    var final = navigator.Snapshot().Single();
    return new
    {
        clearPathAfterFirstActualStep = clearPath, firstActual, joinAfterChange, nullPathAfterChange,
        arrivedAndHeld200LogicalTicks = stable >= 2000, executedMicrosteps = executed, stableMicrostepIntervals = stable, holdDurationMilliseconds = stable * 5, holdMaximumDriftMm, stoppedMicrosteps = stopped,
        final = new { id = final.Id, position = new[] { final.Position.X, final.Position.Y }, state = final.State.ToString(), goal = final.GoalCell },
        bodySweeps = oracle.BodySweeps, pairSweeps = oracle.PairSweeps, metrics = navigator.Metrics.ToDictionary(pair => pair.Key, pair => pair.Value)
    };
}
var control = Run(false);
var afterEmptyChange = Run(true);
Console.WriteLine(JsonSerializer.Serialize(new
{
    scope = "Independent regression using fixed old B0 DLL with identical shared-query Core/Oracle binaries and original geometry/tolerances. New U fixture and empty-change call are explicit; not a published49-case result or claim about the cause of Forest failure.",
    coreAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Point2).Assembly.Location))).ToLowerInvariant(),
    oracleAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(ContinuousOracle).Assembly.Location))).ToLowerInvariant(),
    candidateAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant(),
    input = new { width, height, cellSizeMm = 500, origin = new[] { 0, -60 }, spawn, goal, radiusMm = 250, speedMmPer50Ms = 55, attackRangeMm = 1000,
        walkable = new string(walk.Select(value => value ? '1' : '0').ToArray()), holding = new string(holding.Select(value => value ? '1' : '0').ToArray()),
        target = new { x = 750, y = 5190, radiusMm = 500 }, gatheringDistanceMm = 4000 },
    witnessOnlyNotFedToCandidate = witness.Select(point => new[] { point.X, point.Y }).ToArray(),
    control, afterEmptyChange
}, new JsonSerializerOptions { WriteIndented = true }));
