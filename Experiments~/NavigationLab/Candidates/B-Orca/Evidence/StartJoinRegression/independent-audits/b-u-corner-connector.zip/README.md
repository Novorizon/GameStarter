# B0: actual U-control corner connector precision query

This is a pure read-only query at the actual endpoint of the previously executed no-change U control. It uses the same old frozen B0 DLL `8175992a5d009fe91ee8e6707feabc1e3f7a69c04ad3242315f06e54d5da36b7`, exact unchanged U world and radius250. It does not run a revised candidate or claim a correction is complete.

The actual point `(9249.985694885254,2193.1560039520264)` is itself accepted by candidate zero-tolerance circle geometry. The original static A* route from the exact spawn has 69 nodes and actually contains the next strict node `(9250,2440)`. Yet the segment from the actual point to that existing node is rejected at zero tolerance and accepted both at the already-defined candidate execution tolerance 0.025 mm and by the unchanged shared Oracle 0.1 mm band.

Fresh Find from this actual point is not null: it first selects the preceding corner node `(9250,2190)`, 3.156036 mm away. That exceeds the internal waypoint capture radius 0.25 mm. The local static query therefore exposes another connector/shortcut precision mismatch at an actual control endpoint, separate from the initial float start whose ClosestJoin is -1.

A consistent actual-position-to-existing-strict-node numerical connection check can be investigated without changing static stand eligibility, ordinary grid edges, physical bodies, goals or the shared criterion. This query does not prove that such a change resolves every corner or that the old U control already passed. The companion original traces explicitly retain the fact that neither old U run completed in 7000 steps.

Program.cs reconstructs its exact world and actual point from `b-u-reacquire-old/query.json`, verifies that the queried node really occurs in the original strict path, and records exact-DLL geometry results. manifest.json binds the dependency and all local code/binaries/output. No candidate or shared harness file was changed.
