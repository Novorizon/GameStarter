using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.Candidates.BOrca;

using var data = JsonDocument.Parse(File.ReadAllBytes("/workspace/navigation-comparison/audit/b-u-reacquire-old/query.json"));
var input = data.RootElement.GetProperty("input");
var final = data.RootElement.GetProperty("control").GetProperty("final").GetProperty("position");
var actual = new Point2(final[0].GetDouble(), final[1].GetDouble());
var origin = input.GetProperty("origin");
var target = input.GetProperty("target");
int spawn = input.GetProperty("spawn").GetInt32();
int goal = input.GetProperty("goal").GetInt32();
var world = new WorldDefinition(
    input.GetProperty("width").GetInt32(),
    input.GetProperty("height").GetInt32(),
    input.GetProperty("cellSizeMm").GetInt32(),
    new Point2(origin[0].GetDouble(), origin[1].GetDouble()),
    input.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    input.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    new[] { spawn },
    new[] { new TargetDefinition(1, new Point2(target.GetProperty("x").GetDouble(), target.GetProperty("y").GetDouble()), target.GetProperty("radiusMm").GetInt32()) },
    input.GetProperty("gatheringDistanceMm").GetInt32());
var assembly = typeof(OrcaFactory).Assembly;
var flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
var routeType = assembly.GetType("NavigationLab.Candidates.BOrca.RouteMesh", true)!;
var geometryType = assembly.GetType("NavigationLab.Candidates.BOrca.Geometry", true)!;
var mesh = Activator.CreateInstance(routeType, flags, null, new object[] { world, 250d }, null)!;
List<Point2>? Find(Point2 start)
{
    object?[] query = { start, world.Center(goal), null, 0, null, int.MaxValue };
    return (List<Point2>?)routeType.GetMethod("Find", flags)!.Invoke(mesh, query);
}
var originalPath = Find(world.Center(spawn))!;
var currentPath = Find(actual);
var next = new Point2(9250, 2440);
bool Clear(Point2 point, double tolerance) => (bool)geometryType.GetMethod("Clear", flags)!.Invoke(null, new object[] { world, actual, point, 250d, true, tolerance })!;
bool originalContains = originalPath.Contains(next);
bool strict = Clear(next, 0);
bool execution = Clear(next, .025);
bool oracle = ContinuousOracle.SegmentFits(world, actual, next, 250);
if (!originalContains || strict || !execution || !oracle || currentPath == null)
{
    throw new Exception("Expected actual corner connector mismatch was not reproduced.");
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    scope = "Pure static query at the actual old control endpoint. No revised candidate execution or guaranteed corner correction is claimed.",
    candidateAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant(),
    actual = new[] { actual.X, actual.Y }, existingStrictNode = new[] { next.X, next.Y },
    originalPathContainsNode = originalContains, originalPathNodeCount = originalPath.Count,
    candidateZeroToleranceConnector = strict, candidateExistingExecutionToleranceConnector = execution, sharedOracleConnector = oracle,
    currentPointZeroToleranceCircleClear = Clear(actual, 0),
    currentFindFirstPoint = new[] { currentPath[0].X, currentPath[0].Y },
    currentFindFirstPointDistanceMm = Point2.Distance(actual, currentPath[0]),
    note = "The local start itself is valid here. Replanning selects the preceding corner centre, while zero-tolerance shortcutting rejects a nearly tangent connector to the existing next node. This is separate from the initial float start returning no join."
}, new JsonSerializerOptions { WriteIndented = true }));
