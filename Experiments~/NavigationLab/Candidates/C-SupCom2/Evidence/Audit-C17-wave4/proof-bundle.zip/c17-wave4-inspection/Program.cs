using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

const string resultRoot = "../c17-wave4";
const int actorId = 24;
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "inputs/forest-wave-4.json")));
using var originalReport = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "original-report.json")));
using var witness = JsonDocument.Parse(File.ReadAllBytes("../c17-wave4/query-result.json"));
var source = input.RootElement.GetProperty("world");
int width = source.GetProperty("width").GetInt32();
int height = source.GetProperty("height").GetInt32();
int cellSize = source.GetProperty("cellSizeMm").GetInt32();
var origin = source.GetProperty("origin");
var world = new WorldDefinition(
    width,
    height,
    cellSize,
    new Point2(origin.GetProperty("x").GetDouble(), origin.GetProperty("y").GetDouble()),
    source.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    source.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    source.GetProperty("gatheringDistanceMm").GetInt32());
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => value.GetProperty("id").GetInt32(), value => new SpawnRequest(
    value.GetProperty("id").GetInt32(),
    new UnitProfile(value.GetProperty("radiusMm").GetInt32(), value.GetProperty("speedMmPerTick").GetInt32(), value.GetProperty("attackRangeMm").GetInt32()),
    value.GetProperty("spawnCell").GetInt32(),
    value.GetProperty("targetId").GetInt32(),
    value.GetProperty("assignedGoalCell").GetInt32()));
var initial = originalReport.RootElement.GetProperty("FinalState").GetString()!.Split('|').Select(value =>
{
    var parts = value.Split(':');
    var coordinates = parts[1].Split(',');
    return new UnitSnapshot(
        int.Parse(parts[0]),
        new Point2(
            double.Parse(coordinates[0], System.Globalization.CultureInfo.InvariantCulture),
            double.Parse(coordinates[1], System.Globalization.CultureInfo.InvariantCulture)),
        (MotionState)int.Parse(parts[2]),
        int.Parse(parts[3]),
        int.Parse(parts[4]));
}).OrderBy(value => value.Id).ToArray();
var actor = initial.Single(value => value.Id == actorId);
var profile = requests[actorId].Profile;
var path = witness.RootElement.GetProperty("path").EnumerateArray().Select(value => new Point2(value[0].GetDouble(), value[1].GetDouble())).ToArray();
Require(
    path.Length > 1 && path[0] == actor.Position && path[path.Length - 1] == world.Center(actor.GoalCell),
    "Witness endpoints differ from actual failed case.");

var factory = new NavigationLab.CSupCom2.Factory();
using var navigator = factory.Create(world, requests.Values.Select(value => value.Profile).Distinct().ToArray());
const BindingFlags fields = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
var navigatorType = navigator.GetType();
var actorDictionary = (System.Collections.IDictionary)navigatorType.GetField("actors", fields)!.GetValue(navigator)!;
var commands = originalReport.RootElement.GetProperty("Commands").EnumerateArray().ToArray();
int commandIndex = 0;
var tail = new List<object>();
for (int microstep = 0; microstep <= 70000; microstep++)
{
    while (commandIndex < commands.Length && commands[commandIndex].GetProperty("microstep").GetInt32() == microstep)
    {
        var command = commands[commandIndex++];
        string kind = command.GetProperty("kind").GetString()!;
        int id = command.GetProperty("Id").GetInt32();
        Require(kind == "spawn" || kind == "spawn-rejected", "Unexpected non-birth command in wave4.");
        bool accepted = navigator.TrySpawn(requests[id]);
        Require(accepted == (kind == "spawn"), "Recorded birth result differed at " + microstep);
    }
    navigator.Step();
    if (microstep >= 69000)
    {
        object unit = actorDictionary[actorId]!;
        Point2 point = (Point2)Get(unit, "Position")!;
        tail.Add(new
        {
            microstep = microstep + 1,
            x = point.X,
            y = point.Y,
            stuck = Get(unit, "Stuck"),
            goal = Get(unit, "Goal"),
            yieldGoal = Get(unit, "YieldGoal")
        });
    }
}
var snapshot = navigator.Snapshot().OrderBy(value => value.Id).ToArray();
string canonical = string.Join("|", snapshot.Select(value => value.Id + ":" + value.Position.X.ToString("R") + ","
    + value.Position.Y.ToString("R") + ":" + (int)value.State + ":" + value.GoalCell + ":" + value.TargetId));
Require(canonical == originalReport.RootElement.GetProperty("FinalState").GetString(), "Frozen DLL command replay differs from actual original final state.");
object actorObject = actorDictionary[actorId]!;
object planner = Get(navigator, "planner")!;
int destinationCell = (int)Get(actorObject, "YieldGoal")!;
if (destinationCell < 0)
{
    destinationCell = (int)Get(actorObject, "Goal")!;
}
object? originalRoute = Get(actorObject, "Route");
object? routeClone = null;
if (originalRoute != null)
{
    routeClone = Activator.CreateInstance(originalRoute.GetType(), true)!;
    foreach (var field in originalRoute.GetType().GetFields(fields))
    {
        object? value = field.GetValue(originalRoute);
        field.SetValue(routeClone, value is Array array ? array.Clone() : value);
    }
}
Point2 currentPosition = (Point2)Get(actorObject, "Position")!;
var guideArguments = new object?[] { currentPosition, destinationCell, profile.RadiusMm, routeClone };
object? returned = planner.GetType().GetMethod("Guide", fields)!.Invoke(planner, guideArguments);
Point2? actualGuide = returned == null ? null : (Point2)returned;
double? guideGap = actualGuide.HasValue ? snapshot.Where(value => value.Id != actorId).Min(value =>
    ContinuousOracle.DistanceToSegment(value.Position, currentPosition, actualGuide.Value) - profile.RadiusMm - requests[value.Id].Profile.RadiusMm) : null;
object? motionQuery = null;
if (actualGuide.HasValue)
{
    var actorType = actorObject.GetType();
    var ordered = Array.CreateInstance(actorType, actorDictionary.Count);
    int index = 0;
    foreach (var value in snapshot)
    {
        object body = actorDictionary[value.Id]!;
        actorType.GetField("Previous", fields)!.SetValue(body, value.Position);
        actorType.GetField("Processed", fields)!.SetValue(body, value.Id != actorId);
        ordered.SetValue(body, index++);
    }
    Point2 preferred = (actualGuide.Value - currentPosition).Normalized;
    double remaining = Point2.Distance(currentPosition, world.Center(destinationCell));
    double maximumStep = profile.SpeedMmPerTick / (double)SimulationProtocol.Substeps;
    double guideDistance = Math.Min(remaining, Point2.Distance(currentPosition, actualGuide.Value));
    double distance = Math.Min(maximumStep, guideDistance);
    Point2 forward = currentPosition + preferred * distance;
    bool forwardSafe = (bool)navigatorType.GetMethod("SafeMotion", fields)!.Invoke(navigator, new object[] { actorObject, forward, ordered })!;
    Point2 chosen = (Point2)navigatorType.GetMethod("PickMotion", fields)!.Invoke(
        navigator,
        new object[] { actorObject, preferred, actualGuide.Value, distance, ordered })!;
    motionQuery = new
    {
        scope = "Proposal query after resetting only Previous/Processed metadata to equivalent next-frame snapshot; physical bodies unchanged.",
        guideSegmentStaticClear = ContinuousOracle.SegmentFits(world, currentPosition, actualGuide.Value, profile.RadiusMm),
        guideSegmentMinimumOtherBodyGapMm = guideGap,
        exactForward = new { x = forward.X, y = forward.Y },
        exactForwardSafeMotionPassed = forwardSafe,
        selected = new { x = chosen.X, y = chosen.Y },
        selectedDiffersFromForwardMm = Point2.Distance(chosen, forward),
        selectedDistanceToGuide = Point2.Distance(chosen, actualGuide.Value),
        oldDistanceToGuide = Point2.Distance(currentPosition, actualGuide.Value)
    };
}
var result = new
{
    success = true,
    scope = "Actual frozen C17 command replay and read-only route/steering queries from wave4 failed state; not a new matrix pass.",
    originalFinalStateExactlyMatched = true,
    commandsExecuted = commandIndex,
    microstepsExecuted = 70001,
    candidateSha256 = FileHash(typeof(NavigationLab.CSupCom2.Factory).Assembly.Location),
    inputFileSha256 = FileHash("../c17-wave4/inputs/forest-wave-4.json"),
    originalReportSha256 = FileHash("../c17-wave4/original-report.json"),
    actorId,
    currentPosition = new { x = currentPosition.X, y = currentPosition.Y },
    goal = Get(actorObject, "Goal"),
    yieldGoal = Get(actorObject, "YieldGoal"),
    yieldRequester = Get(actorObject, "YieldRequester"),
    yieldUntil = Get(actorObject, "YieldUntil"),
    stuck = Get(actorObject, "Stuck"),
    progressAnchor = new { x = ((Point2)Get(actorObject, "ProgressAnchor")!).X, y = ((Point2)Get(actorObject, "ProgressAnchor")!).Y },
    bestDistance = Get(actorObject, "BestDistance"),
    siegeWindowBest = Get(actorObject, "SiegeWindowBest"),
    destinationCellActuallyUsed = destinationCell,
    guide = actualGuide.HasValue ? new { x = actualGuide.Value.X, y = actualGuide.Value.Y } : null,
    routeBefore = originalRoute == null ? null : RouteDescription(originalRoute),
    motionQuery,
    sourceSha256 = FileHash("Program.cs"),
    tail
};
File.WriteAllText("inspection-result.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine("PASS actual final state matched after70001steps; actual route/guide/motion proposal recorded.");

static object? Get(object value, string name)
{
    return value.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)!.GetValue(value);
}

static object RouteDescription(object route)
{
    return new { nodes = Get(route, "Nodes"), phase = Get(route, "Phase"), goal = Get(route, "Goal"), version = Get(route, "GraphVersion") };
}

static string FileHash(string name) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(name))).ToLowerInvariant();

static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
