import heapq
import json
import math
from pathlib import Path

# Reuse only the immutable setup and independent geometry configuration, before its fine search.
source = Path('query.py').read_text()
exec(compile(source[:source.index('queue = []')], 'query.py', 'exec'), globals())
centers = {cell: (geometry.origin[0] + (cell % geometry.width + .5) * geometry.size,
                  geometry.origin[1] + (cell // geometry.width + .5) * geometry.size)
           for cell in range(geometry.width * geometry.height)}
stand = {cell: geometry.clear(point, point) for cell, point in centers.items()}
source_x = math.floor((start[0] - geometry.origin[0]) / geometry.size)
source_y = math.floor((start[1] - geometry.origin[1]) / geometry.size)
source_cell = source_y * geometry.width + source_x
connections = [cell for cell, point in centers.items() if abs(cell % geometry.width - source_x) <= 2
               and abs(cell // geometry.width - source_y) <= 2 and stand[cell] and geometry.clear(start, point)]
results = []
for single_source in [True, False]:
    if single_source:
        starts = [source_cell] if stand[source_cell] and geometry.clear(start, centers[source_cell]) else []
    else:
        starts = connections
    for diagonal in [False, True]:
        costs = {cell: math.dist(start, centers[cell]) for cell in starts}
        parents = {cell: None for cell in starts}
        queue = [(cost + math.dist(centers[cell], goal), cost, cell) for cell, cost in costs.items()]
        heapq.heapify(queue)
        visited = set()
        while queue:
            _, cost, cell = heapq.heappop(queue)
            if cell in visited:
                continue
            visited.add(cell)
            if cell == actors[identifier]['goal']:
                break
            x, y = cell % geometry.width, cell // geometry.width
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    if (not dx and not dy) or not diagonal and abs(dx) + abs(dy) != 1:
                        continue
                    nx, ny = x + dx, y + dy
                    if not 0 <= nx < geometry.width or not 0 <= ny < geometry.height:
                        continue
                    nxt = ny * geometry.width + nx
                    if nxt in visited or not stand[nxt] or not geometry.clear(centers[cell], centers[nxt]):
                        continue
                    candidate = cost + math.dist(centers[cell], centers[nxt])
                    if candidate < costs.get(nxt, math.inf):
                        costs[nxt] = candidate
                        parents[nxt] = cell
                        heapq.heappush(queue, (candidate + math.dist(centers[nxt], goal), candidate, nxt))
        path = []
        if actors[identifier]['goal'] in visited:
            cell = actors[identifier]['goal']
            while cell is not None:
                path.append(cell)
                cell = parents[cell]
            path.reverse()
        results.append({
            'diagonal': diagonal, 'strictOriginalSourceCellOnly': single_source,
            'originalCellSizeMm': 500, 'otherActualBodiesFixed': 24,
            'originalCenterConnections': starts, 'expanded': len(visited), 'goalReachable': bool(path),
            'pathCells': path, 'pathPoints': ([start] + [centers[cell] for cell in path]) if path else []
        })
result = {
    'scope': 'Independent original500mm cell-center graph query with both strict actual source cell and optional visible5x5 connections. '
             'Every point and edge checked against original static geometry and24 actual resident bodies. No new candidate execution.',
    'results': results
}
Path('original-grid-query.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
