# C17 Forest wave4：终端门户被当作出口

本目录是只读诊断与独立可行性证据。原正式C17 `forest-wave-4` 在tick7000失败：25人全部生成，14攻击、10候场、1移动。没有修改地图、身体、Goal或C候选，也没有将见证路线提供给候选。

最后移动者id24，r240、速度65mm/50ms、射程450mm，实际位置 `(4146.298634420814,-2668.451169345254)`，原Goal259为 `(8750,-4810)`。另24个身体已实际驻留。

## 原条件下有合法单体路

- 25mm独立查询找到外侧上沿、右缘、下沿的13段路线，长10871.78mm，所有24个驻留者保持原位。
- 正式同Core/Oracle DLL逐5ms实际验证：1679微步、8395ms，随后保持200逻辑tick；最终15攻击、10候场。1,104,300次pair sweep，最小身体间距+0.603mm，保持漂移0。
- **不需要细化原格图。** 额外仅从当前原格426接入，在原500mm格心、四邻逐点逐边检查全部身体与静态扫掠，也存在26格路线（88展开）；八邻同样可达。另有5×5可见连接的对照，但没有把它混成严格原格起点的证明。

这是从原失败合法末态开始的独立运动见证，不声称C17执行了该路径。初次审计脚本误将到Goal的24号标成Waiting，被Oracle正确拒绝；已改为按真实射程/视线确定Attacking并重新通过。`rejected-witness-state-label.log`不计为候选失败。

## 实际缓存状态与fresh查询不同

相邻目录 `../c17-wave4-inspection` 使用正式冻结C17 DLL重放原48个出生/拒绝命令及70001微步，所有结果与原记录一致，完整最终状态逐字相同。其后克隆实际Route作查询，未改变身体位置：

- 24号 `Goal=259`、`YieldGoal=-1`、`Stuck=58000`。
- 最后1001微步只在X约4144.85—4153.32、Y约−2690.55—−2665.26间抖动。
- 实际缓存Route为 `[17,16,7]`、Phase2；Guide返回 `(3750,-2810)`，即驻留15号的身体中心。整段body gap为−420mm；exact forward被SafeMotion正确拒绝。
- 同实际位置/Goal创建fresh Route却返回空Nodes，Guide为 `(4750,-3310)`，整段对其他身体最小间距+0.819mm。不能用fresh结果冒充实际缓存结果，也不能据此直接改普通steering评分。

## 终端门户语义

`../c17-wave4-portals` 对同冻结图作确定性查询：

| 门户 | 分区 | 位置 | Peer分区 |
| --- | --- | --- | --- |
| 17 | 8 | `(5250,-2310)` | 3 |
| 16 | 3 | `(5250,-2810)` | 8 |
| 7，Route末端 | 3 | `(4250,-3310)` | 2 |

当前原格426、Goal259都在分区3；当前格到Goal的**分区内部**原图距离7843.75，明确可达。Route把分区内finish portal7保存在节点末端，Guide却继续将其当作向Peer分区2离开的出口，因而保留错误阶段并导向驻留身体。

对应修复方向是：进入目标分区且其内部实际连通Goal时结束门户阶段，使用Goal field。不能仅按“分区相同”无条件截断，因为一个分区可能含多个不连通部分。修复效果仍须由候选新版本在原场景和共同矩阵中验证；这里不宣称已修复或商业《最高指挥官2》具有此缺陷。

## 复现

保持三个目录相邻：`c17-wave4`、`c17-wave4-inspection`、`c17-wave4-portals`。

```bash
# c17-wave4目录
python3 query.py
python3 original-grid.py
dotnet run --project Replay.csproj -c Release

# ../c17-wave4-inspection目录
dotnet run --project Inspection.csproj -c Release

# ../c17-wave4-portals目录
dotnet run --project Portals.csproj -c Release
```

需要Python3与.NET8 SDK。`FrozenDlls`与原正式构建manifest逐字匹配，`frozen-source.zip`保存对应源。原输入、原报告、所有查询与结果、实际末1001步轨迹均保留；共同封存索引在相邻的 `c17-wave4-manifest.json`。重跑前应复制目录，避免覆盖原封存结果。
