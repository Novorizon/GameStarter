using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

const string resultRoot = ".";
const int actorId = 24;
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "inputs/forest-wave-4.json")));
using var originalReport = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "original-report.json")));
using var witness = JsonDocument.Parse(File.ReadAllBytes("query-result.json"));
var source = input.RootElement.GetProperty("world");
int width = source.GetProperty("width").GetInt32();
int height = source.GetProperty("height").GetInt32();
int cellSize = source.GetProperty("cellSizeMm").GetInt32();
var origin = source.GetProperty("origin");
var world = new WorldDefinition(
    width,
    height,
    cellSize,
    new Point2(origin.GetProperty("x").GetDouble(), origin.GetProperty("y").GetDouble()),
    source.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    source.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    source.GetProperty("gatheringDistanceMm").GetInt32());
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => value.GetProperty("id").GetInt32(), value => new SpawnRequest(
    value.GetProperty("id").GetInt32(),
    new UnitProfile(value.GetProperty("radiusMm").GetInt32(), value.GetProperty("speedMmPerTick").GetInt32(), value.GetProperty("attackRangeMm").GetInt32()),
    value.GetProperty("spawnCell").GetInt32(),
    value.GetProperty("targetId").GetInt32(),
    value.GetProperty("assignedGoalCell").GetInt32()));
var initial = originalReport.RootElement.GetProperty("FinalState").GetString()!.Split('|').Select(value =>
{
    var parts = value.Split(':');
    var coordinates = parts[1].Split(',');
    return new UnitSnapshot(
        int.Parse(parts[0]),
        new Point2(
            double.Parse(coordinates[0], System.Globalization.CultureInfo.InvariantCulture),
            double.Parse(coordinates[1], System.Globalization.CultureInfo.InvariantCulture)),
        (MotionState)int.Parse(parts[2]),
        int.Parse(parts[3]),
        int.Parse(parts[4]));
}).OrderBy(value => value.Id).ToArray();
var actor = initial.Single(value => value.Id == actorId);
var profile = requests[actorId].Profile;
var path = witness.RootElement.GetProperty("path").EnumerateArray().Select(value => new Point2(value[0].GetDouble(), value[1].GetDouble())).ToArray();
Require(
    path.Length > 1 && path[0] == actor.Position && path[path.Length - 1] == world.Center(actor.GoalCell),
    "Witness endpoints differ from actual failed case.");

// Read-only fresh-flow query against the actual frozen candidate DLL.
var assembly = typeof(NavigationLab.CSupCom2.Factory).Assembly;
const BindingFlags internalInstance = BindingFlags.Instance | BindingFlags.NonPublic;
var flowType = assembly.GetType("NavigationLab.CSupCom2.FlowTiles")!;
var metrics = new Dictionary<string, long>();
var flow = Activator.CreateInstance(flowType, internalInstance, null, new object[] { world, metrics }, null)!;
var queryArguments = new object?[] { actor.Position, actor.GoalCell, profile.RadiusMm, null };
var returned = flowType.GetMethod("Guide", internalInstance)!.Invoke(flow, queryArguments);
Point2? guide = returned == null ? null : (Point2)returned;
var bodyType = assembly.GetType("NavigationLab.CSupCom2.CrowdBody")!;
var bodies = Array.CreateInstance(bodyType, initial.Length - 1);
int bodyIndex = 0;
foreach (var other in initial.Where(value => value.Id != actorId))
{
    var body = Activator.CreateInstance(bodyType, internalInstance, null, new object[] { other.Position, requests[other.Id].Profile.RadiusMm }, null)!;
    bodies.SetValue(body, bodyIndex++);
}
var costs = (double[])flowType.GetMethod("TrafficCosts", internalInstance)!.Invoke(flow, new object[] { actor.Position, profile.RadiusMm, bodies })!;
double guideBodyGap = guide.HasValue ? initial.Where(value => value.Id != actorId).Min(other =>
    ContinuousOracle.DistanceToSegment(other.Position, actor.Position, guide.Value) - profile.RadiusMm - requests[other.Id].Profile.RadiusMm) : double.NaN;
var plannerQuery = new
{
    sourceCell = world.CellAt(actor.Position),
    sourceCellCanStand = flowType.GetMethod("CanStand", internalInstance)!.Invoke(flow, new object[] { world.CellAt(actor.Position), profile.RadiusMm }),
    guide = guide.HasValue ? new { x = guide.Value.X, y = guide.Value.Y } : null,
    guideSegmentStaticClear = guide.HasValue && ContinuousOracle.SegmentFits(world, actor.Position, guide.Value, profile.RadiusMm),
    guideSegmentMinimumOtherBodyGapMm = double.IsFinite(guideBodyGap) ? (double?)guideBodyGap : null,
    trafficGoalCost = double.IsFinite(costs[actor.GoalCell]) ? (double?)costs[actor.GoalCell] : null,
    metrics
};
// Seed the independently validated original failed state. This does not pretend to replay candidate history or original births.
var oracle = new ContinuousOracle(world);
var live = (Dictionary<int, SpawnRequest>)typeof(ContinuousOracle).GetField("live", internalInstance)!.GetValue(oracle)!;
foreach (var value in initial)
{
    live.Add(value.Id, requests[value.Id]);
}
oracle.ValidateTransition(initial, initial, 0);
var current = initial;
int microsteps = 0;
double distanceMoved = 0;
var replayStates = new List<object>();
for (int segment = 1; segment < path.Length; segment++)
{
    Point2 destination = path[segment];
    while (Point2.Distance(current.Single(value => value.Id == actorId).Position, destination) > 1e-7)
    {
        Point2 from = current.Single(value => value.Id == actorId).Position;
        Point2 vector = destination - from;
        double distance = Math.Min(vector.Length, profile.SpeedMmPerTick / (double)SimulationProtocol.Substeps);
        Point2 to = from + vector.Normalized * distance;
        var next = current.Select(value => ReplaceActor(value, actorId, to, MotionState.Moving)).ToArray();
        oracle.ValidateTransition(current, next, SimulationProtocol.MicrostepMilliseconds);
        current = next;
        distanceMoved += distance;
        microsteps++;
        replayStates.Add(new { microstep = microsteps, x = to.X, y = to.Y, state = 0 });
    }
}
Point2 finalPosition = current.Single(value => value.Id == actorId).Position;
bool finalActorAttacks = ContinuousOracle.CanAttack(world, finalPosition, profile, world.Target(actor.TargetId));
MotionState finalActorState = finalActorAttacks ? MotionState.Attacking : MotionState.Waiting;
var final = current.Select(value => ReplaceActor(value, actorId, value.Position, finalActorState)).ToArray();
oracle.ValidateTransition(current, final, 0);
for (int hold = 0; hold < 200 * SimulationProtocol.Substeps; hold++)
{
    oracle.ValidateTransition(final, final, SimulationProtocol.MicrostepMilliseconds);
}
Require(
    final.All(value => value.State != MotionState.Moving) && final.Count(value => value.State == MotionState.Attacking) == 15,
    "Witness did not complete 15 attack +10 wait.");
var result = new
{
    success = true,
    scope = "Independent original-radius witness from C17 wave4 actual failed state with24 other actual settled bodies fixed. "
        + "Not successful candidate execution.",
    inputFileSha256 = FileHash("inputs/forest-wave-4.json"),
    originalReportSha256 = FileHash("original-report.json"),
    canonicalInputSha256 = originalReport.RootElement.GetProperty("InputSha256").GetString(),
    candidateAssemblySha256 = FileHash(assembly.Location),
    coreAssemblySha256 = FileHash(typeof(Point2).Assembly.Location),
    oracleAssemblySha256 = FileHash(typeof(ContinuousOracle).Assembly.Location),
    actorId,
    originalRadiusMm = profile.RadiusMm,
    originalSpeedMmPer50ms = profile.SpeedMmPerTick,
    preservedGoal = actor.GoalCell,
    otherFixedBodies = initial.Length - 1,
    movementMicrosteps = microsteps,
    movementMilliseconds = microsteps * SimulationProtocol.MicrostepMilliseconds,
    movedDistanceMm = distanceMoved,
    holdLogicalTicks = 200,
    holdDriftMm = 0,
    pairSweeps = oracle.PairSweeps,
    bodySweeps = oracle.BodySweeps,
    minimumBodyGapMm = oracle.MinimumBodyGapMm,
    maximumObservedStepMm = oracle.MaximumObservedStepMm,
    finalAttack = final.Count(value => value.State == MotionState.Attacking),
    finalWait = final.Count(value => value.State == MotionState.Waiting),
    scriptSha256 = FileHash("Program.cs"),
    pathSha256 = FileHash("query-result.json"),
    freshPlannerQuery = plannerQuery
};
File.WriteAllText("replay-result.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
static string FileHash(string name) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(name))).ToLowerInvariant();

static UnitSnapshot ReplaceActor(UnitSnapshot value, int id, Point2 position, MotionState state)
{
    return value.Id == id ? new UnitSnapshot(id, position, state, value.GoalCell, value.TargetId) : value;
}

static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
