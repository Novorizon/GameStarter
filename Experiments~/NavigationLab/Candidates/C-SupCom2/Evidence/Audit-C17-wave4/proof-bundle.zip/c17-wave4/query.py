import hashlib
import heapq
import json
import math
from pathlib import Path
import geometry

root = Path(__file__).resolve().parent
case_bytes = (root / 'inputs/forest-wave-4.json').read_bytes()
report_bytes = (root / 'original-report.json').read_bytes()
case = json.loads(case_bytes)
report = json.loads(report_bytes)
world = case['world']
requests = {value['id']: value for value in case['requests']}
actors = {}
for item in report['FinalState'].split('|'):
    identifier, point, state, goal, target = item.split(':')
    actors[int(identifier)] = {'position': tuple(map(float, point.split(','))), 'state': int(state), 'goal': int(goal), 'target': int(target)}

identifier = 24
geometry.world = world
geometry.width = world['width']
geometry.height = world['height']
geometry.size = world['cellSizeMm']
geometry.origin = world['origin']['x'], world['origin']['y']
geometry.radius = requests[identifier]['radiusMm']
geometry.others = [(i, value['position'], requests[i]['radiusMm']) for i, value in actors.items() if i != identifier]
cell = actors[identifier]['goal']
goal = (geometry.origin[0] + (cell % geometry.width + .5) * geometry.size,
        geometry.origin[1] + (cell // geometry.width + .5) * geometry.size)
start = actors[identifier]['position']
spacing = 25
lattice = geometry.origin[0] + geometry.size * .5, geometry.origin[1] + geometry.size * .5
start_node = (math.floor((start[0] - lattice[0]) / spacing), math.floor((start[1] - lattice[1]) / spacing))
goal_node = (round((goal[0] - lattice[0]) / spacing), round((goal[1] - lattice[1]) / spacing))
assert geometry.clear(start, start)
assert all(value['state'] != 0 for i, value in actors.items() if i != identifier)

def position(node):
    return lattice[0] + node[0] * spacing, lattice[1] + node[1] * spacing

queue = []
parents = {}
costs = {}
standable = {}
connections = []
for dx in range(-1, 2):
    for dy in range(-1, 2):
        node = start_node[0] + dx, start_node[1] + dy
        point = position(node)
        if geometry.clear(point, point) and geometry.clear(start, point):
            cost = math.dist(start, point)
            costs[node] = cost
            parents[node] = None
            heapq.heappush(queue, (cost + math.dist(point, goal), cost, node))
            connections.append(point)
visited = set()
budget = 100000
while queue and len(visited) < budget:
    _, cost, node = heapq.heappop(queue)
    if node in visited:
        continue
    visited.add(node)
    if node == goal_node:
        break
    point = position(node)
    for dx in range(-1, 2):
        for dy in range(-1, 2):
            if dx == 0 and dy == 0:
                continue
            nxt = node[0] + dx, node[1] + dy
            if nxt in visited:
                continue
            nxt_point = position(nxt)
            if nxt not in standable:
                standable[nxt] = geometry.clear(nxt_point, nxt_point)
            if not standable[nxt] or not geometry.clear(point, nxt_point):
                continue
            candidate = cost + math.dist(point, nxt_point)
            if candidate < costs.get(nxt, math.inf):
                costs[nxt] = candidate
                parents[nxt] = node
                heapq.heappush(queue, (candidate + math.dist(nxt_point, goal), candidate, nxt))
path = []
if goal_node in visited:
    node = goal_node
    while node is not None:
        path.append(position(node))
        node = parents[node]
    path.append(start)
    path.reverse()
    simple = [start]
    index = 0
    while index < len(path) - 1:
        last = len(path) - 1
        while last > index + 1 and not geometry.clear(path[index], path[last]):
            last -= 1
        simple.append(path[last])
        index = last
    path = simple
result = {
    'scope': 'Independent fixed24-neighbor original-radius geometry query from actual C17 wave4 failed state; not candidate execution.',
    'inputFileSha256': hashlib.sha256(case_bytes).hexdigest(), 'reportSha256': hashlib.sha256(report_bytes).hexdigest(),
    'canonicalInputSha256': report['InputSha256'],
    'actor': identifier, 'profile': requests[identifier], 'start': start, 'goalCell': cell, 'goal': goal,
    'otherBodiesFixed': len(geometry.others), 'otherBodiesAllActuallySettled': True,
    'startClear': geometry.clear(start, start), 'destinationClear': geometry.clear(goal, goal),
    'initialOriginalCenterClearConnection': geometry.clear(start, (4250, -2810)),
    'directGoalClear': geometry.clear(start, goal),
    'spacingMm': spacing, 'expanded': len(visited), 'budget': budget, 'budgetExhausted': len(visited) >= budget,
    'initialFineConnections': connections, 'witnessFound': bool(path), 'path': path,
    'lengthMm': sum(math.dist(a, b) for a, b in zip(path, path[1:]))
}
if path:
    result['minimumBodyGapMm'] = min(math.sqrt(geometry.dist2_segment(p, a, b)) - geometry.radius - r
                                      for a, b in zip(path, path[1:]) for _, p, r in geometry.others)
(root / 'query-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
