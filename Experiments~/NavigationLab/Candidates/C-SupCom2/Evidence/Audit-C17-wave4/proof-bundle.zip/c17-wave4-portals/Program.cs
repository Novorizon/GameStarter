using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

const string resultRoot = "../c17-wave4";
const int actorId = 24;
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "inputs/forest-wave-4.json")));
using var originalReport = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "original-report.json")));
using var witness = JsonDocument.Parse(File.ReadAllBytes("../c17-wave4/query-result.json"));
var source = input.RootElement.GetProperty("world");
int width = source.GetProperty("width").GetInt32();
int height = source.GetProperty("height").GetInt32();
int cellSize = source.GetProperty("cellSizeMm").GetInt32();
var origin = source.GetProperty("origin");
var world = new WorldDefinition(
    width,
    height,
    cellSize,
    new Point2(origin.GetProperty("x").GetDouble(), origin.GetProperty("y").GetDouble()),
    source.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    source.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    source.GetProperty("gatheringDistanceMm").GetInt32());
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => value.GetProperty("id").GetInt32(), value => new SpawnRequest(
    value.GetProperty("id").GetInt32(),
    new UnitProfile(value.GetProperty("radiusMm").GetInt32(), value.GetProperty("speedMmPerTick").GetInt32(), value.GetProperty("attackRangeMm").GetInt32()),
    value.GetProperty("spawnCell").GetInt32(),
    value.GetProperty("targetId").GetInt32(),
    value.GetProperty("assignedGoalCell").GetInt32()));
var initial = originalReport.RootElement.GetProperty("FinalState").GetString()!.Split('|').Select(value =>
{
    var parts = value.Split(':');
    var coordinates = parts[1].Split(',');
    return new UnitSnapshot(
        int.Parse(parts[0]),
        new Point2(
            double.Parse(coordinates[0], System.Globalization.CultureInfo.InvariantCulture),
            double.Parse(coordinates[1], System.Globalization.CultureInfo.InvariantCulture)),
        (MotionState)int.Parse(parts[2]),
        int.Parse(parts[3]),
        int.Parse(parts[4]));
}).OrderBy(value => value.Id).ToArray();
var actor = initial.Single(value => value.Id == actorId);
var profile = requests[actorId].Profile;
var path = witness.RootElement.GetProperty("path").EnumerateArray().Select(value => new Point2(value[0].GetDouble(), value[1].GetDouble())).ToArray();
Require(
    path.Length > 1 && path[0] == actor.Position && path[path.Length - 1] == world.Center(actor.GoalCell),
    "Witness endpoints differ from actual failed case.");

const BindingFlags fields = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
var assembly = typeof(NavigationLab.CSupCom2.Factory).Assembly;
var flowType = assembly.GetType("NavigationLab.CSupCom2.FlowTiles")!;
var flow = Activator.CreateInstance(flowType, fields, null, new object[] { world, new Dictionary<string, long>() }, null)!;
object graph = flowType.GetMethod("Graph", fields)!.Invoke(flow, new object[] { profile.RadiusMm })!;
var portals = (System.Collections.IList)graph.GetType().GetField("Portals", fields)!.GetValue(graph)!;
int goalSector = actor.GoalCell % world.Width / 10 + actor.GoalCell / world.Width / 10 * ((world.Width + 9) / 10);
int sourceCell = world.CellAt(actor.Position);
int sourceSector = sourceCell % world.Width / 10 + sourceCell / world.Width / 10 * ((world.Width + 9) / 10);
object goalDistances = flowType.GetMethod("GridDistances", fields)!.Invoke(flow, new object[] { graph, goalSector, actor.GoalCell })!;
double Distance(int cell) => (double)goalDistances.GetType().GetProperty("Item", fields)!.GetValue(goalDistances, new object[] { cell })!;
var descriptions = new List<object>();
foreach (int id in new[] { 17, 16, 7 })
{
    object portal = portals[id]!;
    int[] cells = (int[])portal.GetType().GetField("Cells", fields)!.GetValue(portal)!;
    int center = cells[cells.Length / 2];
    int peerId = (int)portal.GetType().GetField("Peer", fields)!.GetValue(portal)!;
    object peer = portals[peerId]!;
    double toGoal = Distance(center);
    descriptions.Add(new
    {
        id,
        sector = portal.GetType().GetField("Sector", fields)!.GetValue(portal),
        centerCell = center,
        centerPoint = new { x = world.Center(center).X, y = world.Center(center).Y },
        peerId,
        peerSector = peer.GetType().GetField("Sector", fields)!.GetValue(peer),
        goalWithinSectorCost = double.IsFinite(toGoal) ? (double?)toGoal : null
    });
}
object? freshRoute = flowType.GetMethod("Route", fields)!.Invoke(flow, new object[] { sourceCell, actor.GoalCell, profile.RadiusMm });
int[] freshNodes = freshRoute == null ? Array.Empty<int>() : (int[])freshRoute.GetType().GetField("Nodes", fields)!.GetValue(freshRoute)!;
double currentGoalCost = Distance(sourceCell);
var result = new
{
    success = true,
    scope = "Read-only deterministic radius240 portal graph query in original frozen C17; confirms terminal-node semantics without candidate trajectory rerun.",
    candidateSha256 = FileHash(assembly.Location),
    inputSha256 = FileHash("../c17-wave4/inputs/forest-wave-4.json"),
    sourceCell,
    sourceSector,
    goal = actor.GoalCell,
    goalSector,
    currentGoalWithinSectorCost = double.IsFinite(currentGoalCost) ? (double?)currentGoalCost : null,
    freshRouteNodes = freshNodes,
    originalCachedRouteNodes = new[] { 17, 16, 7 },
    originalCachedPhase = 2,
    portals = descriptions,
    sourceSha256 = FileHash("Program.cs")
};
File.WriteAllText("portal-result.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));

static string FileHash(string name) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(name))).ToLowerInvariant();

static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
