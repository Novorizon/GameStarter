# C27初始44人的独立协同见证

见相邻 [`c27-late/README.zh-CN.md`](../c27-late/README.zh-CN.md)。本程序从已逐字重放核对的C27失败末态建立Oracle live请求，保持41个驻留身体不动，按明确的独立几何路径移动原11/19/22，并只在同profile、同target、未Assigned的三人间交换原Goal集合。

结果为492个5ms实际步、2460ms后44人全部到位，18攻击26候场；再稳定200逻辑tick。它不是候选自行执行，不证明原3999前提通过，未来2个Small未生成。

```bash
dotnet run --project Witness.csproj -c Release
```

需保持本目录与 `c27-late` 相邻。此程序使用的waypoint只用于独立可行性证明；另一个`c27-late`中的反事实仅注入Goal循环，未向原控制器提供这些waypoint。
