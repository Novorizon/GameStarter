using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

const string resultRoot = "../c27-late";
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "inputs/forest-full44-two-late-small.json")));
using var originalReport = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "original-report.json")));
var source = input.RootElement.GetProperty("world");
int width = source.GetProperty("width").GetInt32();
int height = source.GetProperty("height").GetInt32();
int cellSize = source.GetProperty("cellSizeMm").GetInt32();
var origin = source.GetProperty("origin");
var world = new WorldDefinition(
    width,
    height,
    cellSize,
    new Point2(origin.GetProperty("x").GetDouble(), origin.GetProperty("y").GetDouble()),
    source.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    source.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    source.GetProperty("gatheringDistanceMm").GetInt32());
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => value.GetProperty("id").GetInt32(), value => new SpawnRequest(
    value.GetProperty("id").GetInt32(),
    new UnitProfile(value.GetProperty("radiusMm").GetInt32(), value.GetProperty("speedMmPerTick").GetInt32(), value.GetProperty("attackRangeMm").GetInt32()),
    value.GetProperty("spawnCell").GetInt32(),
    value.GetProperty("targetId").GetInt32(),
    value.GetProperty("assignedGoalCell").GetInt32()));
var initial = originalReport.RootElement.GetProperty("FinalState").GetString()!.Split('|').Select(value =>
{
    var parts = value.Split(':');
    var coordinates = parts[1].Split(',');
    return new UnitSnapshot(
        int.Parse(parts[0]),
        new Point2(
            double.Parse(coordinates[0], System.Globalization.CultureInfo.InvariantCulture),
            double.Parse(coordinates[1], System.Globalization.CultureInfo.InvariantCulture)),
        (MotionState)int.Parse(parts[2]),
        int.Parse(parts[3]),
        int.Parse(parts[4]));
}).OrderBy(value => value.Id).ToArray();
using var witness = JsonDocument.Parse(File.ReadAllBytes("../c27-late/cooperative-witness.json"));
var goals = witness.RootElement.GetProperty("goalPermutation").EnumerateObject().ToDictionary(value => int.Parse(value.Name), value => value.Value.GetInt32());
Require(goals.Keys.All(id => requests[id].AssignedGoalCell < 0), "Explicit goal cannot change.");
Require(goals.Keys.Select(id => requests[id].Profile).Distinct().Count() == 1, "Profiles differ.");
Require(goals.Keys.Select(id => requests[id].TargetId).Distinct().Count() == 1, "Targets differ.");
var oldGoals = initial.Where(actor => goals.ContainsKey(actor.Id)).Select(actor => actor.GoalCell).OrderBy(cell => cell);
Require(goals.Values.OrderBy(cell => cell).SequenceEqual(oldGoals), "Final goal set changed.");
var oracle = new ContinuousOracle(world);
var live = (Dictionary<int, SpawnRequest>)typeof(ContinuousOracle).GetField("live", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(oracle)!;
foreach (var actor in initial)
{
    live.Add(actor.Id, requests[actor.Id]);
}
oracle.ValidateTransition(initial, initial, 0);
var current = initial.Select(actor => goals.TryGetValue(actor.Id, out int goal)
    ? new UnitSnapshot(actor.Id, actor.Position, MotionState.Moving, goal, actor.TargetId) : actor).ToArray();
oracle.ValidateTransition(initial, current, 0);
int microsteps = 0;
double length = 0;
var actualLegs = new List<object>();
foreach (var move in witness.RootElement.GetProperty("moves").EnumerateArray())
{
    int id = move[0].GetInt32();
    foreach (var coordinate in move[1].EnumerateArray())
    {
        Point2 destination = new Point2(coordinate[0].GetDouble(), coordinate[1].GetDouble());
        Point2 from = current.Single(actor => actor.Id == id).Position;
        int begin = microsteps;
        while (Point2.Distance(current.Single(actor => actor.Id == id).Position, destination) > 1e-7)
        {
            Point2 position = current.Single(actor => actor.Id == id).Position;
            Point2 vector = destination - position;
            double distance = Math.Min(vector.Length, requests[id].Profile.SpeedMmPerTick / (double)SimulationProtocol.Substeps);
            Point2 nextPoint = position + vector.Normalized * distance;
            var next = current.Select(actor => actor.Id == id
                ? new UnitSnapshot(id, nextPoint, MotionState.Moving, actor.GoalCell, actor.TargetId) : actor).ToArray();
            oracle.ValidateTransition(current, next, SimulationProtocol.MicrostepMilliseconds);
            current = next;
            length += distance;
            microsteps++;
        }
        actualLegs.Add(new
        {
            id,
            from = new { x = from.X, y = from.Y },
            to = new { x = destination.X, y = destination.Y },
            microsteps = microsteps - begin
        });
    }
}
var final = current.Select(actor =>
{
    Require(Point2.Distance(actor.Position, world.Center(actor.GoalCell)) <= SimulationProtocol.GoalToleranceMm, "Body off original legal final goal.");
    bool attack = ContinuousOracle.CanAttack(world, actor.Position, requests[actor.Id].Profile, world.Target(actor.TargetId));
    return new UnitSnapshot(actor.Id, actor.Position, attack ? MotionState.Attacking : MotionState.Waiting, actor.GoalCell, actor.TargetId);
}).ToArray();
oracle.ValidateTransition(current, final, 0);
for (int hold = 0; hold < 200 * SimulationProtocol.Substeps; hold++)
{
    oracle.ValidateTransition(final, final, SimulationProtocol.MicrostepMilliseconds);
}
Require(final.Length == 44 && final.Count(actor => actor.State == MotionState.Attacking) == 18, "Initial44 witness incomplete.");
var result = new
{
    success = true,
    scope = "Independent cooperative recovery witness from exact C27 initial44 failed state;41 settled bodies fixed. "
        + "Same3 moving bodies, original radii/speeds and same final Goal set, permuted only among same-profile unassigned actors. "
        + "This is not C27 candidate execution or an initial-check-before3999 proof, and future2 small bodies were not generated.",
    originalReportSha256 = FileHash("../c27-late/original-report.json"),
    sourceSha256 = FileHash("Program.cs"),
    witnessSha256 = FileHash("../c27-late/cooperative-witness.json"),
    coreSha256 = FileHash(typeof(Point2).Assembly.Location),
    oracleSha256 = FileHash(typeof(ContinuousOracle).Assembly.Location),
    candidateReferenceSha256 = FileHash(typeof(NavigationLab.CSupCom2.Factory).Assembly.Location),
    actualBodyCount = final.Length,
    fixedBodyCount = final.Length - goals.Count,
    originalRadiusMm = 250,
    originalSpeedMmPer50ms = 55,
    sameFinalGoalSet = true,
    goalPermutation = goals,
    movementMicrosteps = microsteps,
    movementMilliseconds = microsteps * SimulationProtocol.MicrostepMilliseconds,
    movementLengthMm = length,
    pairSweeps = oracle.PairSweeps,
    bodySweeps = oracle.BodySweeps,
    minimumBodyGapMm = oracle.MinimumBodyGapMm,
    maximumStepMm = oracle.MaximumObservedStepMm,
    finalAttack = final.Count(actor => actor.State == MotionState.Attacking),
    finalWait = final.Count(actor => actor.State == MotionState.Waiting),
    holdLogicalTicks = 200,
    holdDriftMm = 0,
    futureSmallBodiesBorn = 0,
    pendingFutureRequests = 2,
    actualLegs
};
File.WriteAllText("witness-result.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));

static string FileHash(string name) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(name))).ToLowerInvariant();
static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
