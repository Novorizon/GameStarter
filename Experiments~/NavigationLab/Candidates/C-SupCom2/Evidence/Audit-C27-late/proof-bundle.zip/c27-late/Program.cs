using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

const string resultRoot = ".";
using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "inputs/forest-full44-two-late-small.json")));
using var originalReport = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(resultRoot, "original-report.json")));
var source = input.RootElement.GetProperty("world");
int width = source.GetProperty("width").GetInt32();
int height = source.GetProperty("height").GetInt32();
int cellSize = source.GetProperty("cellSizeMm").GetInt32();
var origin = source.GetProperty("origin");
var world = new WorldDefinition(
    width,
    height,
    cellSize,
    new Point2(origin.GetProperty("x").GetDouble(), origin.GetProperty("y").GetDouble()),
    source.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    source.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    source.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(
        value.GetProperty("id").GetInt32(),
        new Point2(value.GetProperty("x").GetDouble(), value.GetProperty("y").GetDouble()),
        value.GetProperty("radiusMm").GetInt32())).ToArray(),
    source.GetProperty("gatheringDistanceMm").GetInt32());
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => value.GetProperty("id").GetInt32(), value => new SpawnRequest(
    value.GetProperty("id").GetInt32(),
    new UnitProfile(value.GetProperty("radiusMm").GetInt32(), value.GetProperty("speedMmPerTick").GetInt32(), value.GetProperty("attackRangeMm").GetInt32()),
    value.GetProperty("spawnCell").GetInt32(),
    value.GetProperty("targetId").GetInt32(),
    value.GetProperty("assignedGoalCell").GetInt32()));
var initial = originalReport.RootElement.GetProperty("FinalState").GetString()!.Split('|').Select(value =>
{
    var parts = value.Split(':');
    var coordinates = parts[1].Split(',');
    return new UnitSnapshot(
        int.Parse(parts[0]),
        new Point2(
            double.Parse(coordinates[0], System.Globalization.CultureInfo.InvariantCulture),
            double.Parse(coordinates[1], System.Globalization.CultureInfo.InvariantCulture)),
        (MotionState)int.Parse(parts[2]),
        int.Parse(parts[3]),
        int.Parse(parts[4]));
}).OrderBy(value => value.Id).ToArray();
var factory = new NavigationLab.CSupCom2.Factory();
var registeredProfiles = requests.Values.Select(request => request.Profile).Distinct().ToArray();
using var navigator = factory.Create(world, registeredProfiles);
const BindingFlags fields = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
var navType = navigator.GetType();
var dictionary = (System.Collections.IDictionary)Get(navigator, "actors")!;
var ownerMap = (Dictionary<int, int>)Get(navigator, "owners")!;
var commands = originalReport.RootElement.GetProperty("Commands").EnumerateArray().ToArray();
int expectedSteps = originalReport.RootElement.GetProperty("CheckedMicrosteps").GetInt32();
int nextCommand = 0;
var selectedIds = new HashSet<int> { 11, 19, 22 };
var signatures = new Dictionary<int, string>();
var events = new List<object>();
var tail = new List<object>();
for (int microstep = 0; microstep < expectedSteps; microstep++)
{
    while (nextCommand < commands.Length && commands[nextCommand].GetProperty("microstep").GetInt32() == microstep)
    {
        var command = commands[nextCommand++];
        int id = command.GetProperty("Id").GetInt32();
        string kind = command.GetProperty("kind").GetString()!;
        Require(kind == "spawn" || kind == "spawn-rejected", "Unexpected command.");
        bool accepted = navigator.TrySpawn(requests[id]);
        Require(accepted == (kind == "spawn"), "Recorded birth result differed at " + microstep);
    }
    navigator.Step();
    foreach (System.Collections.DictionaryEntry entry in dictionary)
    {
        int id = (int)entry.Key;
        if (!selectedIds.Contains(id) && microstep < expectedSteps - 5000)
        {
            continue;
        }
        object actor = entry.Value!;
        int goal = (int)Get(actor, "Goal")!;
        int yield = (int)Get(actor, "YieldGoal")!;
        int requester = (int)Get(actor, "YieldRequester")!;
        long until = (long)Get(actor, "YieldUntil")!;
        bool transfer = (bool)Get(actor, "VacancyTransfer")!;
        bool prefer = (bool)Get(actor, "PreferClearCorridor")!;
        string signature = goal + ":" + yield + ":" + requester + ":" + until + ":" + transfer + ":" + prefer;
        Point2 position = (Point2)Get(actor, "Position")!;
        if (!signatures.TryGetValue(id, out string? last) || last != signature)
        {
            signatures[id] = signature;
            object? requesterObject = dictionary.Contains(requester) ? dictionary[requester] : null;
            events.Add(new
            {
                observationKind = last == null ? "first-observation" : "field-transition",
                microstep = microstep + 1, id, x = position.X, y = position.Y, goal, yieldGoal = yield,
                requester, until, transfer, prefer,
                actorEndOfFrameState = (int)State(navigator, actor),
                requesterEndOfFrameState = requesterObject == null ? (int?)null : (int)State(navigator, requesterObject)
            });
        }
        if (selectedIds.Contains(id) && microstep >= expectedSteps - 1000)
        {
            tail.Add(new { microstep = microstep + 1, id, x = position.X, y = position.Y, stuck = Get(actor, "Stuck"), goal, yieldGoal = yield });
        }
    }
}
var snapshot = navigator.Snapshot().OrderBy(actor => actor.Id).ToArray();
string canonical = string.Join("|", snapshot.Select(actor => actor.Id + ":" + actor.Position.X.ToString("R") + ","
    + actor.Position.Y.ToString("R") + ":" + (int)actor.State + ":" + actor.GoalCell + ":" + actor.TargetId));
Require(canonical == originalReport.RootElement.GetProperty("FinalState").GetString(), "Exact C27 final state differs; no diagnosis accepted.");
Require(nextCommand == commands.Length, "Some recorded API commands were omitted.");
object planner = Get(navigator, "planner")!;
Type actorType = dictionary[selectedIds.First()]!.GetType();
var ordered = Array.CreateInstance(actorType, dictionary.Count);
for (int index = 0; index < snapshot.Length; index++)
{
    ordered.SetValue(dictionary[snapshot[index].Id], index);
}
bool outerMatchingTrigger = snapshot.Any(value =>
{
    object actor = dictionary[value.Id]!;
    return (int)Get(actor, "Stuck")! > 200 && (int)Get(actor, "YieldGoal")! < 0 && InSiege(navigator, actor);
});
var actorQueries = new List<object>();
foreach (int id in selectedIds.OrderBy(id => id))
{
    object actor = dictionary[id]!;
    var profile = requests[id].Profile;
    Point2 position = (Point2)Get(actor, "Position")!;
    int goal = (int)Get(actor, "Goal")!;
    int destination = (int)Get(actor, "YieldGoal")!;
    if (destination < 0)
    {
        destination = goal;
    }
    object? route = CloneRoute(Get(actor, "Route"));
    object? routeBefore = route == null ? null : DescribeRoute(route);
    var guideArguments = new object?[] { position, destination, profile.RadiusMm, route };
    object? guideResult = planner.GetType().GetMethod("Guide", fields)!.Invoke(planner, guideArguments);
    Point2? guide = guideResult == null ? null : (Point2)guideResult;
    double? guideGap = guide.HasValue ? snapshot.Where(other => other.Id != id).Min(other =>
        ContinuousOracle.DistanceToSegment(other.Position, position, guide.Value) - profile.RadiusMm - requests[other.Id].Profile.RadiusMm) : null;
    var bodyType = planner.GetType().Assembly.GetType("NavigationLab.CSupCom2.CrowdBody")!;
    var residents = snapshot.Where(other => other.Id != id && other.State != MotionState.Moving).ToArray();
    var bodies = Array.CreateInstance(bodyType, residents.Length);
    for (int index = 0; index < residents.Length; index++)
    {
        object body = Activator.CreateInstance(
            bodyType,
            fields,
            null,
            new object[] { residents[index].Position, requests[residents[index].Id].Profile.RadiusMm },
            null)!;
        bodies.SetValue(body, index);
    }
    var costs = (double[])planner.GetType().GetMethod("TrafficCosts", fields)!.Invoke(planner, new object[] { position, profile.RadiusMm, bodies })!;
    var canHold = navType.GetMethod("CanHold", fields)!;
    var attack = navType.GetMethod("Attack", fields)!;
    var attackCells = (IEnumerable<int>)navType.GetMethod("AttackCells", fields)!.Invoke(navigator, new[] { actor })!;
    int attackCount = attackCells.Count();
    int originCell = world.CellAt(position);
    bool originStand = (bool)planner.GetType().GetMethod("CanStand", fields)!.Invoke(planner, new object[] { originCell, profile.RadiusMm })!;
    int matchingOrigin = originStand ? originCell : goal;
    var traffic = new List<object>();
    foreach (int cell in new[] { 210, 211, 212 })
    {
        bool hold = (bool)canHold.Invoke(navigator, new object[] { actor, cell })!;
        bool attacks = (bool)attack.Invoke(navigator, new object[] { actor, world.Center(cell) })!;
        bool connected = (bool)planner.GetType().GetMethod("Connected", fields)!.Invoke(planner, new object[] { matchingOrigin, cell, profile.RadiusMm })!;
        double matchingScore = costs[cell] - (attacks ? 1e12 + 1e8 / Math.Max(1, attackCount) : 0);
        traffic.Add(new
        {
            cell, hold, attacks, connected,
            owner = ownerMap.TryGetValue(cell, out int owner) ? owner : (int?)null,
            cost = Finite(costs[cell]),
            matchingScore = hold && connected ? Finite(matchingScore) : null
        });
    }
    actorQueries.Add(new
    {
        id, x = position.X, y = position.Y, goal, actualDestinationCell = destination,
        state = (int)State(navigator, actor), yieldGoal = Get(actor, "YieldGoal"), yieldRequester = Get(actor, "YieldRequester"),
        yieldUntil = Get(actor, "YieldUntil"), transfer = Get(actor, "VacancyTransfer"), preferClear = Get(actor, "PreferClearCorridor"),
        assigned = Get(actor, "AssignedGoal"), stuck = Get(actor, "Stuck"), inSiege = InSiege(navigator, actor),
        originCell, originStand, matchingOrigin, attackCount,
        bestDistance = Finite((double)Get(actor, "BestDistance")!), siegeWindowBest = Finite((double)Get(actor, "SiegeWindowBest")!),
        routeBefore, guide = guide.HasValue ? new { x = guide.Value.X, y = guide.Value.Y } : null,
        guideStaticClear = guide.HasValue && ContinuousOracle.SegmentFits(world, position, guide.Value, profile.RadiusMm),
        guideBodyGap = guideGap, traffic
    });
}
var beforeMatchGoals = snapshot.ToDictionary(actor => actor.Id, actor => actor.GoalCell);
var beforeMatchMetrics = navigator.Metrics.ToDictionary(pair => pair.Key, pair => pair.Value);
navType.GetMethod("RedistributeSiegeGoals", fields)!.Invoke(navigator, new object[] { ordered });
var afterMatch = navigator.Snapshot().OrderBy(actor => actor.Id).ToArray();
Require(snapshot.All(actor => afterMatch.Single(value => value.Id == actor.Id).Position == actor.Position), "Matching query moved a body.");
var normalMatchingQuery = new
{
    scope = "Counterfactual direct call of unchanged C27 normal traffic matcher from copied replay endpoint; "
        + "no additional physical time and no actual-test completion.",
    outerTriggerWouldBeTrueAtEndpoint = outerMatchingTrigger,
    excludedTransferIds = snapshot.Where(value => (bool)Get(dictionary[value.Id]!, "VacancyTransfer")!).Select(value => value.Id).ToArray(),
    goalChanges = afterMatch.Where(actor => beforeMatchGoals[actor.Id] != actor.GoalCell).Select(actor => new
    {
        id = actor.Id, oldGoal = beforeMatchGoals[actor.Id], newGoal = actor.GoalCell
    }).ToArray(),
    beforeMetrics = beforeMatchMetrics,
    afterMetrics = navigator.Metrics.ToDictionary(pair => pair.Key, pair => pair.Value)
};
object? counterfactualCycle = null;
if (args.Contains("--cycle"))
{
    using var intervention = JsonDocument.Parse(File.ReadAllBytes("cooperative-witness.json"));
    var mappings = intervention.RootElement.GetProperty("goalPermutation").EnumerateObject();
    var cycle = mappings.ToDictionary(value => int.Parse(value.Name), value => value.Value.GetInt32());
    Require(cycle.Keys.All(id => requests[id].AssignedGoalCell < 0), "Cycle changed an assigned destination.");
    Require(cycle.Keys.Select(id => requests[id].Profile).Distinct().Count() == 1, "Cycle mixes profiles.");
    Require(cycle.Keys.Select(id => requests[id].TargetId).Distinct().Count() == 1, "Cycle mixes targets.");
    var originalGoals = snapshot.Where(actor => cycle.ContainsKey(actor.Id)).Select(actor => actor.GoalCell).OrderBy(cell => cell);
    Require(cycle.Values.OrderBy(cell => cell).SequenceEqual(originalGoals), "Cycle changed final goal set.");
    var oracle = new ContinuousOracle(world);
    var live = (Dictionary<int, SpawnRequest>)Get(oracle, "live")!;
    foreach (var actor in snapshot)
    {
        live.Add(actor.Id, requests[actor.Id]);
    }
    oracle.ValidateTransition(snapshot, snapshot, 0);
    var commit = navType.GetMethod("CommitGoals", fields)!;
    var changes = (System.Collections.IDictionary)Activator.CreateInstance(commit.GetParameters()[0].ParameterType)!;
    foreach (var pair in cycle)
    {
        changes.Add(dictionary[pair.Key]!, pair.Value);
    }
    commit.Invoke(navigator, new object[] { changes });
    var current = navigator.Snapshot().ToArray();
    oracle.ValidateTransition(snapshot, current, 0);
    Dictionary<int, Point2>? anchor = null;
    int stableMicrosteps = 0;
    int cycleMicrosteps = 0;
    double holdDrift = 0;
    bool complete = false;
    for (int microstep = 1; microstep <= 10000; microstep++)
    {
        var previous = current;
        navigator.Step();
        current = navigator.Snapshot().ToArray();
        oracle.ValidateTransition(previous, current, SimulationProtocol.MicrostepMilliseconds);
        cycleMicrosteps = microstep;
        bool allArrived = current.Length == 44 && current.All(actor => actor.State != MotionState.Moving)
            && current.Count(actor => actor.State == MotionState.Attacking) == 18;
        if (anchor == null)
        {
            if (allArrived && microstep % SimulationProtocol.Substeps == 0)
            {
                anchor = current.ToDictionary(actor => actor.Id, actor => actor.Position);
                stableMicrosteps = 0;
            }
        }
        else
        {
            double drift = current.Max(actor => Point2.Distance(actor.Position, anchor[actor.Id]));
            if (!allArrived || drift > SimulationProtocol.GeometryToleranceMm)
            {
                anchor = null;
                stableMicrosteps = 0;
                holdDrift = 0;
            }
            else
            {
                stableMicrosteps++;
                holdDrift = Math.Max(holdDrift, drift);
                if (stableMicrosteps >= 200 * SimulationProtocol.Substeps)
                {
                    complete = true;
                    break;
                }
            }
        }
    }
    counterfactualCycle = new
    {
        scope = "Only a same-profile unassigned permanent-goal cycle was injected via original CommitGoals; "
            + "the unchanged original C27 Step then ran with original physical bodies and independent Oracle. "
            + "No witness waypoint was passed to the controller. This is not original before3999 acceptance or a generic recovery policy.",
        complete,
        cycle,
        postInterventionMicrosteps = cycleMicrosteps,
        stableLogicalTicks = stableMicrosteps / SimulationProtocol.Substeps,
        holdMaximumDriftMm = holdDrift,
        alive = current.Length,
        moving = current.Count(actor => actor.State == MotionState.Moving),
        attack = current.Count(actor => actor.State == MotionState.Attacking),
        wait = current.Count(actor => actor.State == MotionState.Waiting),
        futureSmallBodiesBorn = 0,
        pairSweeps = oracle.PairSweeps,
        minimumGapMm = oracle.MinimumBodyGapMm,
        final = current.Select(actor => new { actor.Id, x = actor.Position.X, y = actor.Position.Y, state = (int)actor.State, goal = actor.GoalCell }),
        finalMetrics = navigator.Metrics.ToDictionary(pair => pair.Key, pair => pair.Value)
    };
    File.WriteAllText("counterfactual-cycle.json", JsonSerializer.Serialize(counterfactualCycle, new JsonSerializerOptions { WriteIndented = true }) + "\n");
}
var result = new
{
    success = true,
    scope = "Exact frozen C27 late-initial-condition failure replay and read-only queries, not matrix acceptance or an altered original result.",
    originalFinalStateExactlyMatched = true,
    executedCommands = nextCommand,
    executedMicrosteps = expectedSteps,
    registeredProfilesFromAll46Requests = registeredProfiles.Select(profile => new
    {
        radius = profile.RadiusMm,
        speed = profile.SpeedMmPerTick,
        range = profile.AttackRangeMm
    }),
    candidateSha256 = FileHash(typeof(NavigationLab.CSupCom2.Factory).Assembly.Location),
    coreSha256 = FileHash(typeof(Point2).Assembly.Location),
    oracleSha256 = FileHash(typeof(ContinuousOracle).Assembly.Location),
    inputSha256 = FileHash("inputs/forest-full44-two-late-small.json"),
    reportSha256 = FileHash("original-report.json"),
    sourceSha256 = FileHash("Program.cs"),
    actorQueries,
    normalMatchingQuery,
    counterfactualCycle,
    operationEvents = events,
    tail
};
File.WriteAllText("probe-result.json", JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine("PASS exact C27 state matched after" + expectedSteps + " steps; " + events.Count + " operation transitions recorded.");

static object? Get(object value, string name)
{
    return value.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)!.GetValue(value);
}

static MotionState State(INavigator navigator, object actor)
{
    return (MotionState)navigator.GetType().GetMethod("State", BindingFlags.Instance | BindingFlags.NonPublic)!.Invoke(navigator, new[] { actor })!;
}

static bool InSiege(INavigator navigator, object actor)
{
    return (bool)navigator.GetType().GetMethod("InSiegeArea", BindingFlags.Instance | BindingFlags.NonPublic)!.Invoke(navigator, new[] { actor })!;
}

static object? CloneRoute(object? route)
{
    if (route == null)
    {
        return null;
    }
    object copy = Activator.CreateInstance(route.GetType(), true)!;
    foreach (var field in route.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
    {
        object? value = field.GetValue(route);
        field.SetValue(copy, value is Array array ? array.Clone() : value);
    }
    return copy;
}

static object DescribeRoute(object route)
{
    return new { nodes = Get(route, "Nodes"), phase = Get(route, "Phase"), goal = Get(route, "Goal"), version = Get(route, "GraphVersion") };
}
static double? Finite(double value) => double.IsFinite(value) ? value : null;
static string FileHash(string name) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(name))).ToLowerInvariant();

static void Require(bool condition, string message)
{
    if (!condition)
    {
        throw new InvalidOperationException(message);
    }
}
