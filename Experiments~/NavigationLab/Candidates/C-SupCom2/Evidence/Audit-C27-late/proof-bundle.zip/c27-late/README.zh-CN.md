# C27晚到场景：初始44人的互阻

原测试没有通过初始前提：tick3999时44个Big已经生成，未来2个Small尚未出生，`InitialBatchVerified=false`，3人仍Moving。不能把它写成“44稳定后46失败”。重放注册的是完整46请求的两个profile：Big `(r250,speed55,range550)`、未来Small `(r180,speed165,range450)`；省略未来profile会改变Rarity与初始分配。

## 精确重放

封存C27候选DLL为 `c999fdcf…41799e`，Core和Oracle与原开发summary逐字相同。431条真实出生/拒绝命令、39990个实际5ms Step全部执行，完整最终状态逐字匹配原报告；原C27的4份源也逐字匹配原sourceBefore/sourceAfter。

| 身体 | 当前Goal | 当前Yield | 保护flag | 实际Guide的body gap |
| --- | --- | --- | --- | --- |
| 11 | 211 | −1 | false | −263.59mm |
| 19 | 210 | −1 | false | −224.40mm |
| 22 | 212 | −1 | false | −73.57mm |

三人的Route都是正确的空门户序列，Guide直接指向各自Goal；不是此前wave4终端门户缓存错误。Stuck分别12400、12400、25400；最后1000步各自位置完全不变。只有19的`PreferClearCorridor=true`，但Guide被实际身体阻挡，清晰走廊的前置条件不成立。没有残留VacancyTransfer保护阻止匹配。

## Hungarian为什么没有交换

外部触发条件在末态为true；在复制重放末态中直接调用原匹配器，也没有任何Goal变化。三人对210/211/212的CanHold、静态连通约束均为true，AttackCells均18，且都Moving，没有已到位者的10000稳定惩罚。

| 身体 | 210的交通成本 | 211的交通成本 | 212的交通成本 |
| --- | --- | --- | --- |
| 11 | 634.114 | 390.000 | 890.000 |
| 19 | 719.034 | 1133.145 | 1633.145 |
| 22 | 275.597 | 236.411 | 732.002 |

所有排列都保留一个同profile攻击格212，攻击奖励抵消。当前分配总代价1841.036；仅交换11/22变为1845.445，反而高4.409。下述可执行三循环的代价2298.741，也更高。因此，未换Goal是当前代理目标函数的正常结果，不能归咎于Hungarian没有执行或目标被flag锁住。

当前交通诊断主要考虑静态格图和已驻留者的代价，不能表达三个Moving的互相阻挡及某一目标排列能否按实际先后执行。这是本项目目标协调层的能力缺口，不是商业流场算法的来源结论。尚未证明必须采用某一种Goal循环或不存在其他恢复方法。

## 独立运动见证与原控制器反事实

保持41个驻留者固定，原3个身体、原速度/半径、原最终Goal集合不变，仅同profile、同target、未Assigned的三人交换Goal：22→210，11→212，19→211。独立见证先让22沿局部曲线进入210，再让11经211到212，最后19沿原地图底边进入211。

相邻目录 `../c27-late-witness` 使用原Core/Oracle逐5ms验证：492微步、2460ms，44人全部到位，18攻击、26候场，随后200tick稳定；最小body gap0，2,360,270次pair sweep。没有生成未来2个Small。

另一个更窄的反事实仅向原C27内存副本调用原`CommitGoals`，注入上述同profile Goal循环，**不向候选提供任何见证waypoint**。随后原C27 Step自己完成全部运动：4640微步（含200tick保持），44人全到、18攻击26候场，Oracle检查4,391,332次pair sweep，最小间距0。其最终44个Goal集合与原集合一致。

这说明当前控制器能够执行一种解除互阻的分配，目标层尚不能自行选出它。两种见证都从原失败末态开始，不是原3999前提通过，也不是完整晚到46通过；未来2个Small仍未生成。一般修复仍须自行推导Goal选择并在原输入完整重放，不能读取这些具体ID、Goal或路线作为生产策略。

## 文件与复现

保留 `c27-late`、`c27-late-witness` 两目录相邻。

```bash
# c27-late目录：精确回放、原匹配器查询与仅Goal循环干预
dotnet run --project Probe.csproj -c Release -- --cycle

# ../c27-late-witness目录：独立实际运动见证
dotnet run --project Witness.csproj -c Release
```

需要.NET8 SDK。`probe-result.json`包括完整原状态、Route/flags、交通成本、操作字段变化及末1000步；事件明确区分首次观察与真实字段变化，requesterState只表示帧结束时状态，不冒充私有方法调用瞬间状态。`normalMatchingQuery`是在复制末态作的零时间诊断调用，不改变身体。

`candidate-source.zip`、`FrozenDlls`、原输入/报告/开发summary及所有结果均保留。共同封存索引为相邻的 `c27-late-manifest.json`。重跑前先复制目录，以免覆盖封存结果。
