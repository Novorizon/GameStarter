import math

def dist2_segment(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = dx * dx + dy * dy
    t = 0 if length == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / length))
    return (p[0] - a[0] - t * dx) ** 2 + (p[1] - a[1] - t * dy) ** 2

def rectangle2(a, b, rect):
    left, bottom, right, top = rect
    low, high = 0, 1
    intersects = True
    for axis, minimum, maximum in [(0, left, right), (1, bottom, top)]:
        delta = b[axis] - a[axis]
        if abs(delta) < 1e-12:
            if not minimum <= a[axis] <= maximum:
                intersects = False
                break
        else:
            one, two = (minimum - a[axis]) / delta, (maximum - a[axis]) / delta
            low, high = max(low, min(one, two)), min(high, max(one, two))
            if low > high:
                intersects = False
                break
    if intersects:
        return 0
    def point_rect(p):
        return max(left - p[0], 0, p[0] - right) ** 2 + max(bottom - p[1], 0, p[1] - top) ** 2
    return min(point_rect(a), point_rect(b), *(dist2_segment(corner, a, b) for corner in [(left, bottom), (right, bottom), (right, top), (left, top)]))

def clear(a, b, stationary=True):
    if min(a[0], b[0]) < origin[0] + radius - 1e-7 or min(a[1], b[1]) < origin[1] + radius - 1e-7:
        return False
    if max(a[0], b[0]) > origin[0] + width * size - radius + 1e-7 or max(a[1], b[1]) > origin[1] + height * size - radius + 1e-7:
        return False
    for target in world['targets']:
        if dist2_segment((target['x'], target['y']), a, b) < (target['radiusMm'] + radius - 1e-7) ** 2:
            return False
    for rect in candidate_rectangles(a, b):
        if max(a[0], b[0]) + radius < rect[0] or min(a[0], b[0]) - radius > rect[2] or max(a[1], b[1]) + radius < rect[1] or min(a[1], b[1]) - radius > rect[3]:
            continue
        if rectangle2(a, b, rect) < (radius - 1e-7) ** 2:
            return False
    if stationary:
        for _, position, other_radius in others:
            if dist2_segment(position, a, b) < (radius + other_radius - 1e-7) ** 2:
                return False
    return True


def candidate_rectangles(a, b):
    min_x = max(0, math.floor((min(a[0], b[0]) - radius - origin[0]) / size))
    max_x = min(width - 1, math.floor((max(a[0], b[0]) + radius - origin[0]) / size))
    min_y = max(0, math.floor((min(a[1], b[1]) - radius - origin[1]) / size))
    max_y = min(height - 1, math.floor((max(a[1], b[1]) + radius - origin[1]) / size))
    for y in range(min_y, max_y + 1):
        for x in range(min_x, max_x + 1):
            if world['walkable'][y * width + x] == '0':
                left = origin[0] + x * size
                bottom = origin[1] + y * size
                yield left, bottom, left + size, bottom + size
