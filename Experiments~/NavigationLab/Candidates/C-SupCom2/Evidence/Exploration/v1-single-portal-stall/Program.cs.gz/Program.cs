using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.CSupCom2;
using System.Text.Json;

var forestLines=File.ReadAllLines("/workspace/navigation-comparison/c-supcom2/Assets/GameAssets/TowerDefense/Data/ForestNavigation.bytes").Where(s=>s.Trim().Length>0&&!s.StartsWith(';')).ToArray();
int w=int.Parse(forestLines[1].Split(' ')[1]),h=int.Parse(forestLines[1].Split(' ')[2]);
int cell=int.Parse(forestLines[2].Split(' ')[1]);
var origin=forestLines[3].Split(' ');var target=forestLines[4].Split(' ');
var walk=new bool[w*h];var holding=new bool[w*h];var spawns=new List<int>();
for(int row=0;row<h;row++)for(int x=0;x<w;x++){int id=(h-row-1)*w+x;char ch=forestLines[6+row][x];walk[id]=".+aBS".Contains(ch);holding[id]=ch=='a';if(ch=='S')spawns.Add(id);}
var forest=new WorldDefinition(w,h,cell,new Point2(int.Parse(origin[1]),int.Parse(origin[2])),walk,holding,spawns.ToArray(),new[]{new TargetDefinition(1,new Point2(int.Parse(target[1]),int.Parse(target[2])),int.Parse(target[3]))});
var width=37;var height=37;var open=new WorldDefinition(width,height,1000,default,Enumerable.Repeat(true,width*height).ToArray(),Enumerable.Repeat(true,width*height).ToArray(),new[]{18*width+1},new[]{new TargetDefinition(1,new Point2(28_500,18_500),1000)});
string only=args.FirstOrDefault()??"all";
foreach(var spec in new[]{("open-single",open,new UnitProfile(250,1000,550),1,true),("forest-single",forest,new UnitProfile(250,55,550),1,true),("forest-eight",forest,new UnitProfile(200,100,450),8,false),("forest-44",forest,new UnitProfile(250,55,550),44,false)})
{
 if(only!="all"&&!spec.Item1.Contains(only))continue;
 var world=spec.Item2;var profile=spec.Item3;using var nav=new Factory().Create(world,new[]{profile});var oracle=new ContinuousOracle(world);int next=1,stable=0;bool passed=false;int tick=0;
 int goal=Enumerable.Range(0,world.CellCount).Where(c=>world.HoldingAllowed(c)&&ContinuousOracle.CircleFits(world,world.Center(c),profile.RadiusMm)&&Point2.Distance(world.Center(c),world.Target(1).Center)<world.Target(1).RadiusMm+profile.RadiusMm+profile.AttackRangeMm).OrderByDescending(c=>world.Center(c).X).ThenBy(c=>c).First();
 try
 {
 for(tick=0;tick<12000;tick++)
 {
  if(next<=spec.Item4){var request=new SpawnRequest(next,profile,world.SpawnCells[0],1,spec.Item5?goal:-1);var before=nav.Snapshot();if(nav.TrySpawn(request)){oracle.RegisterBirth(request,before,nav.Snapshot());next++;}else oracle.VerifyRejectedBirth(before,nav.Snapshot());}
  for(int micro=0;micro<10;micro++){var before=nav.Snapshot();nav.Step();oracle.ValidateTransition(before,nav.Snapshot(),5);}
  var units=nav.Snapshot();if(next>spec.Item4&&units.All(u=>u.State!=MotionState.Moving)){if(++stable>=200){passed=true;break;}}else stable=0;
  if(tick%500==0)Console.WriteLine($"{spec.Item1} tick={tick} born={next-1} settled={units.Count(u=>u.State!=MotionState.Moving)} failure={nav.LastSpawnFailure} sample="+JsonSerializer.Serialize(units.Take(3).Select(u=>new{u.Id,x=u.Position.X,y=u.Position.Y,u.GoalCell,u.State})));
 }
 }
 catch(Exception e){Console.WriteLine("GEOMETRYFAIL "+e);}
 if(!passed)Dump(nav,world);
 var result=new{spec.Item1,passed,tick,born=next-1,units=nav.Snapshot().Select(u=>new{u.Id,x=u.Position.X,y=u.Position.Y,u.GoalCell,u.State}),metrics=nav.Metrics,oracle.PairSweeps,oracle.BodySweeps};File.WriteAllText("/workspace/navigation-comparison/c-smoke/"+spec.Item1+".json",JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine("RESULT "+JsonSerializer.Serialize(new{spec.Item1,passed,tick,born=next-1,settled=nav.Snapshot().Count(u=>u.State!=MotionState.Moving),metrics=nav.Metrics}));
}

static void Dump(INavigator nav,WorldDefinition world)
{
 object? F(object x,string n)=>x.GetType().GetField(n,System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Public)?.GetValue(x);
 var planner=F(nav,"planner")!; var graphs=(System.Collections.IDictionary)F(planner,"graphs")!;
 foreach(System.Collections.DictionaryEntry de in graphs)
 {
  var graph=de.Value!;var portals=(System.Collections.IList)F(graph,"Portals")!;var stand=(bool[])F(graph,"Stand")!;
  var actors=(System.Collections.IDictionary)F(nav,"actors")!;
  foreach(System.Collections.DictionaryEntry ae in actors)
  {
   var actor=ae.Value!;var pos=(Point2)F(actor,"Position")!;int cell=world.CellAt(pos);var route=F(actor,"Route");Console.WriteLine($"DEBUG cell={cell} x={cell%world.Width} y={cell/world.Width} actor={ae.Key}");
   if(route!=null){int phase=(int)F(route,"Phase")!;int[] nodes=(int[])F(route,"Nodes")!;Console.WriteLine("DEBUG route="+string.Join(',',nodes)+" phase="+phase);foreach(int n in nodes){var pp=portals[n]!;Console.WriteLine("DEBUG portal="+n+" sector="+F(pp,"Sector")+" cells="+string.Join(',',(int[])F(pp,"Cells")!));}}
   var fields=(System.Collections.IDictionary)F(planner,"fields")!;foreach(System.Collections.DictionaryEntry ff in fields){var field=ff.Value!;var ints=(double[])F(field,"Integration")!;if(!double.IsInfinity(ints[cell])){Console.WriteLine("DEBUG field="+ff.Key);foreach(int n in new[]{cell-world.Width,cell-1,cell,cell+1,cell+world.Width})Console.WriteLine($"DEBUG n={n} stand={stand[n]} cost={ints[n]}");}}
  }
 }
}
