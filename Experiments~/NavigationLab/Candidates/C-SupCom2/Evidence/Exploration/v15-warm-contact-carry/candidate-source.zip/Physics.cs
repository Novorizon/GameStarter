using System;
using System.Collections.Generic;
using NavigationLab.Core;

namespace NavigationLab.CSupCom2
{
    internal sealed partial class Navigator
    {
        private readonly struct Contact
        {
            internal int First { get; }
            internal int Second { get; }
            internal Point2 Normal { get; }
            internal double MinimumSeparation { get; }
            internal Contact(int first, int second, Point2 normal, double minimumSeparation)
            {
                First = first;
                Second = second;
                Normal = normal;
                MinimumSeparation = minimumSeparation;
            }
        }

        private void ResolvePhysics(Actor[] ordered, Dictionary<int, Point2> proposals)
        {
            var deltas = new Point2[ordered.Length];
            var anchored = new bool[ordered.Length];
            var anchorRadius = new double[ordered.Length];
            bool anyMotion = false;
            for (int index = 0; index < ordered.Length; index++)
            {
                Actor actor = ordered[index];
                deltas[index] = proposals.TryGetValue(actor.Id, out var next) ? next - actor.Previous : default;
                anchored[index] = actor.YieldGoal < 0 && State(actor) != MotionState.Moving;
                anchorRadius[index] = anchored[index] ? Math.Max(.0001, Point2.Distance(actor.Position, world.Center(actor.Goal))) : 0;
                anyMotion |= deltas[index].LengthSquared > 1e-16;
            }
            if (!anyMotion)
            {
                return;
            }
            var contacts = new List<Contact>();
            for (int first = 0; first < ordered.Length; first++)
            {
                Actor a = ordered[first];
                for (int second = first + 1; second < ordered.Length; second++)
                {
                    Actor b = ordered[second];
                    Point2 relative = a.Previous - b.Previous;
                    double radius = a.Profile.RadiusMm + b.Profile.RadiusMm;
                    double reach = (a.Profile.SpeedMmPerTick + b.Profile.SpeedMmPerTick) / (double)SimulationProtocol.Substeps;
                    if (relative.Length > radius + reach + 1e-6)
                    {
                        continue;
                    }
                    contacts.Add(new Contact(first, second, relative.Normalized, radius - relative.Length));
                }
            }
            for (int iteration = 0; iteration < 128; iteration++)
            {
                double largest = 0;
                foreach (var contact in contacts)
                {
                    double separation = Point2.Dot(deltas[contact.First] - deltas[contact.Second], contact.Normal);
                    double deficit = contact.MinimumSeparation - separation;
                    if (deficit > 1e-8)
                    {
                        double aWeight = anchored[contact.First] ? .02 : 1;
                        double bWeight = anchored[contact.Second] ? .02 : 1;
                        Point2 correction = contact.Normal * (deficit + 2e-9);
                        deltas[contact.First] += correction * (aWeight / (aWeight + bWeight));
                        deltas[contact.Second] -= correction * (bWeight / (aWeight + bWeight));
                        largest = Math.Max(largest, deficit);
                    }
                }
                bool clipped = false;
                for (int index = 0; index < ordered.Length; index++)
                {
                    Actor actor = ordered[index];
                    Point2 before = deltas[index];
                    double maximum = actor.Profile.SpeedMmPerTick / (double)SimulationProtocol.Substeps;
                    if (deltas[index].Length > maximum)
                    {
                        deltas[index] = deltas[index].Normalized * maximum;
                    }
                    deltas[index] = ClipWalls(actor, deltas[index]);
                    if (anchored[index])
                    {
                        Point2 goal = world.Center(actor.Goal);
                        Point2 error = actor.Previous + deltas[index] - goal;
                        if (error.Length > anchorRadius[index])
                        {
                            deltas[index] = goal + error.Normalized * anchorRadius[index] - actor.Previous;
                        }
                    }
                    clipped |= Point2.Distance(before, deltas[index]) > 1e-8;
                }
                Count("PhysicsProjectionIterations");
                if (largest < 1e-7 && !clipped)
                {
                    break;
                }
            }
            double scale = 1;
            int backoffs = 0;
            while (backoffs < 24 && !FrameFits(ordered, contacts, deltas, scale))
            {
                scale *= .5;
                backoffs++;
            }
            if (!FrameFits(ordered, contacts, deltas, scale))
            {
                scale = 0;
                Count("PhysicsHeldFrames");
            }
            if (backoffs > 0)
            {
                Count("PhysicsBackoffFrames");
                Count("PhysicsBackoffSteps", backoffs);
            }
            for (int index = 0; index < ordered.Length; index++)
            {
                Actor actor = ordered[index];
                actor.Velocity = deltas[index] * scale;
                actor.Position = actor.Previous + actor.Velocity;
                if (actor.Velocity.Length > 1e-7 && proposals[actor.Id] == actor.Previous)
                {
                    Count("PhysicalPushMovements");
                }
            }
        }

        private Point2 ClipWalls(Actor actor, Point2 delta)
        {
            if (Geometry.Segment(world, actor.Previous, actor.Previous + delta, actor.Profile.RadiusMm))
            {
                return delta;
            }
            var horizontal = new Point2(delta.X, 0);
            var vertical = new Point2(0, delta.Y);
            bool xFits = Geometry.Segment(world, actor.Previous, actor.Previous + horizontal, actor.Profile.RadiusMm);
            bool yFits = Geometry.Segment(world, actor.Previous, actor.Previous + vertical, actor.Profile.RadiusMm);
            if (xFits || yFits)
            {
                Count("WallSlides");
                return xFits && (!yFits || horizontal.LengthSquared >= vertical.LengthSquared) ? horizontal : vertical;
            }
            double low = 0;
            double high = 1;
            for (int iteration = 0; iteration < 18; iteration++)
            {
                double middle = (low + high) * .5;
                if (Geometry.Segment(world, actor.Previous, actor.Previous + delta * middle, actor.Profile.RadiusMm))
                {
                    low = middle;
                }
                else
                {
                    high = middle;
                }
            }
            return delta * low;
        }

        private bool FrameFits(Actor[] ordered, List<Contact> contacts, Point2[] deltas, double scale)
        {
            for (int index = 0; index < ordered.Length; index++)
            {
                Actor actor = ordered[index];
                if (!Geometry.Segment(world, actor.Previous, actor.Previous + deltas[index] * scale, actor.Profile.RadiusMm))
                {
                    return false;
                }
            }
            foreach (var contact in contacts)
            {
                Actor a = ordered[contact.First];
                Actor b = ordered[contact.Second];
                double gap = Geometry.SweptBodies(a.Previous, a.Previous + deltas[contact.First] * scale,
                    b.Previous, b.Previous + deltas[contact.Second] * scale) - a.Profile.RadiusMm - b.Profile.RadiusMm;
                double initialGap = Point2.Distance(a.Previous, b.Previous) - a.Profile.RadiusMm - b.Profile.RadiusMm;
                // A warm contact must permit zero motion after roundoff. Construction targets zero gap; only a
                // nanometre-scale non-worsening allowance carries an existing deficit, bounded below the oracle.
                double minimum = Math.Max(-SimulationProtocol.GeometryToleranceMm * .01, Math.Min(-1e-6, initialGap - 1e-9));
                if (gap < minimum)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
