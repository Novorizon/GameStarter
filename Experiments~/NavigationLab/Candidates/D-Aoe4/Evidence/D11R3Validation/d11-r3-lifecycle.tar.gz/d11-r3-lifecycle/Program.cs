using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.DAoe4;

string directory = Path.GetFullPath(args[0]);
var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
object? Get(object value, string name) => value.GetType().GetField(name, flags)!.GetValue(value);
void Set(object value, string name, object? fieldValue) => value.GetType().GetField(name, flags)!.SetValue(value, fieldValue);
void Require(bool valid, string error)
{
    if (!valid)
    {
        throw new Exception(error);
    }
}
string Hash(byte[] data) => Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
object? Normalize(object? value)
{
    if (value == null || value is string || value is bool)
    {
        return value;
    }
    if (value is Point2 point)
    {
        return new[] { point.X, point.Y };
    }
    if (value is double number)
    {
        return double.IsFinite(number) ? value : number.ToString("R", CultureInfo.InvariantCulture);
    }
    if (value.GetType().IsPrimitive || value.GetType().IsEnum)
    {
        return value;
    }
    if (value is IDictionary dictionary)
    {
        var result = new SortedDictionary<string, object?>();
        foreach (DictionaryEntry entry in dictionary)
        {
            result[Convert.ToString(entry.Key, CultureInfo.InvariantCulture)!] = Normalize(entry.Value);
        }
        return result;
    }
    if (value is IEnumerable sequence)
    {
        return sequence.Cast<object?>().Select(Normalize).ToArray();
    }
    return value.GetType().GetFields(flags).OrderBy(field => field.Name)
        .ToDictionary(field => field.Name, field => Normalize(field.GetValue(value)));
}
string Signature(INavigator navigator) => Hash(JsonSerializer.SerializeToUtf8Bytes(Normalize(navigator)));
object[] Pose(UnitSnapshot[] snapshot) => snapshot.OrderBy(unit => unit.Id)
    .Select(unit => (object)new { id = unit.Id, x = unit.Position.X, y = unit.Position.Y, goal = unit.GoalCell, state = unit.State.ToString(), target = unit.TargetId }).ToArray();

using var input = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(directory, "source-input.json")));
using var prefix = JsonDocument.Parse(File.ReadAllBytes(Path.Combine(directory, "source-prefix.json")));
var w = input.RootElement.GetProperty("world");
int I(JsonElement value, string name) => value.GetProperty(name).GetInt32();
double D(JsonElement value, string name) => value.GetProperty(name).GetDouble();
var world = new WorldDefinition(
    I(w, "width"),
    I(w, "height"),
    I(w, "cellSizeMm"),
    new Point2(D(w.GetProperty("origin"), "x"), D(w.GetProperty("origin"), "y")),
    w.GetProperty("walkable").GetString()!.Select(value => value == '1').ToArray(),
    w.GetProperty("holding").GetString()!.Select(value => value == '1').ToArray(),
    w.GetProperty("spawnCells").EnumerateArray().Select(value => value.GetInt32()).ToArray(),
    w.GetProperty("targets").EnumerateArray().Select(value => new TargetDefinition(I(value, "id"), new Point2(D(value, "x"), D(value, "y")), I(value, "radiusMm"))).ToArray(),
    I(w, "gatheringDistanceMm"));
var requests = input.RootElement.GetProperty("requests").EnumerateArray().ToDictionary(value => I(value, "id"), value => new SpawnRequest(
    I(value, "id"),
    new UnitProfile(I(value, "radiusMm"), I(value, "speedMmPerTick"), I(value, "attackRangeMm")),
    I(value, "spawnCell"),
    I(value, "targetId"),
    I(value, "assignedGoalCell")));
Require(Hash(File.ReadAllBytes(Path.Combine(directory, "source-input.json"))) == prefix.RootElement.GetProperty("inputSha256").GetString(), "Prefix refers to different original input.");

(INavigator Navigator, ContinuousOracle Oracle) Restore()
{
    var navigator = new Aoe4SlotExchangeFactory().Create(world.Clone(), requests.Values.Select(request => request.Profile).Distinct().ToArray());
    var oracle = new ContinuousOracle(world);
    var actors = (IDictionary)Get(navigator, "actors")!;
    var owners = (IDictionary)Get(navigator, "goalOwners")!;
    var actorType = actors.GetType().GetGenericArguments()[1];
    var live = (IDictionary<int, SpawnRequest>)oracle.Live;
    foreach (var item in prefix.RootElement.GetProperty("actors").EnumerateArray())
    {
        int id = I(item, "id");
        var position = item.GetProperty("position");
        var point = new Point2(position[0].GetDouble(), position[1].GetDouble());
        int goal = I(item, "goalCell");
        var actor = Activator.CreateInstance(actorType, true)!;
        Set(actor, "Request", requests[id]);
        Set(actor, "Position", point);
        Set(actor, "Goal", goal);
        Set(actor, "Velocity", default(Point2));
        Set(actor, "Proposal", default(Point2));
        Set(actor, "ObservationPosition", point);
        Set(actor, "ObservationStep", 10000);
        Set(actor, "LastProgress", I(item, "lastProgress"));
        Set(actor, "BestGoalDistance", Point2.Distance(point, world.Center(goal)));
        actors.Add(id, actor);
        owners.Add(goal, id);
        live.Add(id, requests[id]);
    }
    Set(navigator, "step", 10000);
    var restored = navigator.Snapshot().ToArray();
    oracle.ValidateTransition(restored, restored, 0);
    foreach (var unit in restored)
    {
        var reference = prefix.RootElement.GetProperty("actors").EnumerateArray().Single(value => I(value, "id") == unit.Id);
        Require(unit.Position == new Point2(reference.GetProperty("position")[0].GetDouble(), reference.GetProperty("position")[1].GetDouble())
            && unit.GoalCell == I(reference, "goalCell") && unit.State.ToString() == reference.GetProperty("state").GetString(), "Restore changed original endpoint pose/goal/state.");
    }
    return (navigator, oracle);
}

void CheckReferences(INavigator navigator, int removedId = -1)
{
    var actors = (IDictionary)Get(navigator, "actors")!;
    var owners = (IDictionary)Get(navigator, "goalOwners")!;
    var exchanges = (IDictionary)Get(navigator, "exchanges")!;
    Require(owners.Count == actors.Count, "Goal owner count is not a live-body bijection.");
    var unique = new HashSet<int>();
    foreach (DictionaryEntry entry in actors)
    {
        int id = (int)entry.Key;
        object actor = entry.Value!;
        int goal = (int)Get(actor, "Goal")!;
        Require(unique.Add(goal) && owners.Contains(goal) && (int)owners[goal]! == id, "Goal owner mapping is missing/duplicated.");
        int partner = (int)Get(actor, "ExchangePartner")!;
        if (partner != 0)
        {
            Require(actors.Contains(partner) && partner != removedId && (int)Get(actors[partner]!, "ExchangePartner")! == id, "Stale or nonreciprocal exchange partner.");
            Require(exchanges.Values.Cast<object>().Any(exchange => (int)Get(exchange, "Requester")! == id && (int)Get(exchange, "Holder")! == partner
                || (int)Get(exchange, "Holder")! == id && (int)Get(exchange, "Requester")! == partner), "Partner has no active transaction.");
        }
    }
    foreach (object exchange in exchanges.Values)
    {
        int requester = (int)Get(exchange, "Requester")!;
        int holder = (int)Get(exchange, "Holder")!;
        Require(actors.Contains(requester) && actors.Contains(holder) && requester != removedId && holder != removedId, "Transaction retains a removed participant.");
        Require((int)Get(actors[requester]!, "Goal")! == (int)Get(exchange, "HolderOldGoal")!
            && (int)Get(actors[holder]!, "Goal")! == (int)Get(exchange, "RequesterOldGoal")!, "Transaction goals changed without cancellation.");
    }
}

var results = new List<object>();
string? midSignature = null;
foreach (string operation in new[] { "remove-holder", "remove-requester", "empty-world-change" })
{
    var restored = Restore();
    using var navigator = restored.Navigator;
    var oracle = restored.Oracle;
    var exchanges = (IDictionary)Get(navigator, "exchanges")!;
    int prefixSteps = 0;
    while (prefixSteps < 200)
    {
        var before = navigator.Snapshot().ToArray();
        navigator.Step();
        oracle.ValidateTransition(before, navigator.Snapshot().ToArray(), 5);
        prefixSteps++;
        CheckReferences(navigator);
        if (exchanges.Count > 0)
        {
            object transaction = exchanges.Values.Cast<object>().Single();
            int elapsed = (int)Get(navigator, "step")! - (int)Get(transaction, "Started")!;
            if (elapsed >= 45)
            {
                break;
            }
        }
    }
    Require(exchanges.Count == 1, "Expected one active 5/6 transaction at midpoint.");
    var active = exchanges.Values.Cast<object>().Single();
    int requesterId = (int)Get(active, "Requester")!;
    int holderId = (int)Get(active, "Holder")!;
    Require(new HashSet<int> { requesterId, holderId }.SetEquals(new[] { 5, 6 }), "Different participant pair than the verified 5/6 prefix.");
    Require(!(bool)Get(active, "HolderArrived")! && !(bool)Get(active, "RequesterReleased")!, "Exchange is no longer in holder migration.");
    var actorsAtMid = (IDictionary)Get(navigator, "actors")!;
    var holderAtMid = actorsAtMid[holderId]!;
    Require(((Point2)Get(holderAtMid, "Velocity")!).Length > 0 && Point2.Distance((Point2)Get(holderAtMid, "Position")!, world.Center((int)Get(holderAtMid, "Goal")!)) > .1, "Holder is not actually mid-migration.");
    string signature = Signature(navigator);
    midSignature ??= signature;
    Require(signature == midSignature, "Fresh restoration branches differ in actor/velocity/clock/transaction/route/cache metadata.");
    var beforeApi = navigator.Snapshot().ToArray();
    int removed = operation == "remove-holder" ? holderId : operation == "remove-requester" ? requesterId : -1;
    if (removed >= 0)
    {
        Require(navigator.Remove(removed), "Explicit participant removal failed.");
        oracle.RegisterDeath(removed, beforeApi, navigator.Snapshot().ToArray());
    }
    else
    {
        var change = new WorldChange();
        Require(navigator.ApplyWorldChange(change), "Empty world change rejected.");
        oracle.ApplyChange(change, beforeApi, navigator.Snapshot().ToArray());
    }
    var afterApi = navigator.Snapshot().ToArray();
    oracle.ValidateTransition(afterApi, afterApi, 0);
    Require(afterApi.Length == beforeApi.Length - (removed >= 0 ? 1 : 0), "Wrong body count after instantaneous API.");
    Require(afterApi.All(unit => beforeApi.Single(old => old.Id == unit.Id).Position == unit.Position), "API instantaneously moved a surviving body.");
    Require(exchanges.Count == 0, "Cancelled active transaction was retained.");
    CheckReferences(navigator, removed);
    var actorsAfterApi = (IDictionary)Get(navigator, "actors")!;
    foreach (int participant in new[] { requesterId, holderId }.Where(id => id != removed))
    {
        Require((int)Get(actorsAfterApi[participant]!, "ExchangePartner")! == 0, "Surviving participant retained old waiting reference.");
    }
    for (int step = 0; step < 100; step++)
    {
        var before = navigator.Snapshot().ToArray();
        navigator.Step();
        oracle.ValidateTransition(before, navigator.Snapshot().ToArray(), 5);
        CheckReferences(navigator, removed);
    }
    var final = navigator.Snapshot().ToArray();
    results.Add(new
    {
        operation, requesterId, holderId, prefixSteps, midMicrostep = 10000 + prefixSteps, midpointFullStateSha256 = signature,
        beforeApi = Pose(beforeApi), afterApi = Pose(afterApi), final = Pose(final),
        participantMovementsMm = final.Where(unit => unit.Id == requesterId || unit.Id == holderId)
            .ToDictionary(unit => unit.Id, unit => Point2.Distance(afterApi.Single(before => before.Id == unit.Id).Position, unit.Position)),
        continuationStepsOf5Ms = 100, pairSweeps = oracle.PairSweeps, bodySweeps = oracle.BodySweeps,
        minimumGapMm = oracle.MinimumBodyGapMm, activeTransactionsAfterContinuation = exchanges.Count,
        metrics = navigator.Metrics.ToDictionary(pair => pair.Key, pair => pair.Value)
    });
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    scope = "D11 R3 lifecycle counterfactual: original verified R10 1000-tick poses/profiles/IDs/goals/state restored exactly with zero initial velocity and fresh R3 planning caches, then actual original5/6 exchange observed. Not a from-spawn R3 replay or shared49 coverage claim.",
    candidateAssemblySha256 = Hash(File.ReadAllBytes(typeof(Aoe4SlotExchangeFactory).Assembly.Location)),
    coreAssemblySha256 = Hash(File.ReadAllBytes(typeof(Point2).Assembly.Location)),
    oracleAssemblySha256 = Hash(File.ReadAllBytes(typeof(ContinuousOracle).Assembly.Location)),
    branchesFullMidpointStateIdentical = true, results
}, new JsonSerializerOptions { WriteIndented = true }));
