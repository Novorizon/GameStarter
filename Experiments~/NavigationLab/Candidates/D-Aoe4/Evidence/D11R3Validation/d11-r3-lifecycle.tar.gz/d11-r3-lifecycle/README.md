# D11 R3 active-exchange lifecycle audit

Fixed module: commit `225831fa506831ef588711bb7c09bed68a05b306`, candidate DLL `552672fd11ae36debe9e2014932e2091222b7f6bdb7c9d183a1fba9463a53493`. This is a small counterfactual lifecycle supplement, not extra shared49 coverage or a from-spawn R3 replay.

Each branch independently restores the **exact verified R10 1000-tick positions, IDs, profiles, goals and reported states**, with explicitly zero initial velocity and fresh R3 planning caches, using the existing R3 restore-driver convention. The original input file hash must match the sealed R10 prefix. Initial 0 ms geometry/conservation validation passes. The historical R10 prefix geometry is not re-run or falsely claimed as a full R3 history.

All three fresh restorations advance 55 actual 5 ms steps to microstep10055. The actual first transaction is requester6 / holder5, holder migration is incomplete, and the requester is still held. The **entire candidate instance value state**, including actors/velocities/proposals/clock/transaction booleans/goal map/routes/flow data/planner and geometry caches, has the identical signature `2cffc4dda3bca0fb0195d21b2673c7bd536cf3d65b1854bbb66d9f8efd1bfe83` before branching. No mutable planner or world wrapper is shared between branches.

At that midpoint, separate branches call Remove(holder5), Remove(requester6), or ApplyWorldChange(empty). All pass:

- Exact surviving physical positions are unchanged during the API call; only the explicit removed ID disappears.
- The active transaction and surviving participant waiting references clear immediately. Live goal ownership remains a bijection.
- The original Oracle checks the instantaneous result at 0 ms and every one of the next 100 actual 5 ms steps. All IDs/targets, speed, static/base geometry, body-pair sweep, and attack-state checks pass.
- Reference and goal-owner consistency is rechecked after every continuation step. No stale removed-ID partner or transaction remains.
- The surviving requester moves 550 mm after holder removal; the surviving holder moves its remaining 247 mm after requester removal; after empty change both continue by those amounts. No active transaction remains after the 100-step continuation.

The three branch runs perform 439632 pair sweeps and 20652 body checks in total, including repeated initial/instantaneous validations. Minimum gap is zero at a legal tangent. This demonstrates cancellation and continuation at this actual exchange phase; it is not a claim that all lifecycle phases or all game situations are covered.

Reproduce with `DOTNET_PROCESSOR_COUNT=1 dotnet run --project Query.csproj -c Release -- /absolute/path/to/this/audit`. Snapshot contains the exact queried development candidate/Core/Oracle binaries and relevant module source. Source input/prefix are copied for reproducibility. manifest.json binds them and the original source locations; neither candidate/harness nor the original Unity project is modified.
