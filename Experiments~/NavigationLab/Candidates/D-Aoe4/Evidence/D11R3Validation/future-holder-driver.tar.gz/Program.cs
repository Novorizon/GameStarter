using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.DAoe4;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
var input=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);int ticks=args.Length>2?int.Parse(args[2]):1000;
using var doc=JsonDocument.Parse(File.ReadAllText(input));var w=doc.RootElement.GetProperty("world");
int I(JsonElement x,string n)=>x.GetProperty(n).GetInt32();double D(JsonElement x,string n)=>x.GetProperty(n).GetDouble();
var targets=w.GetProperty("targets").EnumerateArray().Select(t=>new TargetDefinition(I(t,"id"),new Point2(D(t,"x"),D(t,"y")),I(t,"radiusMm"))).ToArray();
var world=new WorldDefinition(I(w,"width"),I(w,"height"),I(w,"cellSizeMm"),new Point2(D(w.GetProperty("origin"),"x"),D(w.GetProperty("origin"),"y")),
 w.GetProperty("walkable").GetString()!.Select(c=>c=='1').ToArray(),w.GetProperty("holding").GetString()!.Select(c=>c=='1').ToArray(),
 w.GetProperty("spawnCells").EnumerateArray().Select(x=>x.GetInt32()).ToArray(),targets,I(w,"gatheringDistanceMm"));
var orders=doc.RootElement.GetProperty("requests").EnumerateArray().Select(x=>(Ready:I(x,"readyTick"),Request:new SpawnRequest(I(x,"id"),new UnitProfile(I(x,"radiusMm"),I(x,"speedMmPerTick"),I(x,"attackRangeMm")),I(x,"spawnCell"),I(x,"targetId"),I(x,"assignedGoalCell")))).ToList();
var profiles=orders.Select(o=>o.Request.Profile).Distinct().ToArray();using var nav=new Aoe4SlotExchangeFactory().Create(world,profiles);var oracle=new ContinuousOracle(world);

var flags=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
object? Get(object o,string n)=>o.GetType().GetField(n,flags)!.GetValue(o);
void Set(object o,string n,object? value)=>o.GetType().GetField(n,flags)!.SetValue(o,value);
using var raw=JsonDocument.Parse(File.ReadAllText("/workspace/navigation-comparison/research-d/audit-r10/forest-prefix-raw.json"));
var actorMap=(System.Collections.IDictionary)Get(nav,"actors")!;
var owners=(System.Collections.IDictionary)Get(nav,"goalOwners")!;
var actorType=actorMap.GetType().GetGenericArguments()[1];
var live=(IDictionary<int,SpawnRequest>)oracle.Live;
var initial=new List<UnitSnapshot>();
foreach(var item in raw.RootElement.GetProperty("actors").EnumerateArray())
{
 int id=I(item,"id");var request=orders.First(o=>o.Request.Id==id).Request;
 var position=item.GetProperty("position").EnumerateArray().Select(x=>x.GetDouble()).ToArray();
 var pos=new Point2(position[0],position[1]);int goal=I(item,"goalCell");
 var actor=Activator.CreateInstance(actorType,true)!;
 Set(actor,"Request",request);Set(actor,"Position",pos);Set(actor,"Goal",goal);
 Set(actor,"Velocity",default(Point2));Set(actor,"Proposal",default(Point2));
 Set(actor,"ObservationPosition",pos);Set(actor,"ObservationStep",10000);Set(actor,"LastProgress",I(item,"lastProgress"));
 Set(actor,"BestGoalDistance",Point2.Distance(pos,world.Center(goal)));
 actorMap.Add(id,actor);owners.Add(goal,id);live.Add(id,request);
}
Set(nav,"step",10000);
initial.AddRange(nav.Snapshot());oracle.ValidateTransition(initial,initial,0);
var reference=raw.RootElement.GetProperty("actors").EnumerateArray().ToDictionary(x=>I(x,"id"),x=>x);
foreach(var unit in initial)
{
 var a=reference[unit.Id];var pos=a.GetProperty("position").EnumerateArray().Select(x=>x.GetDouble()).ToArray();
 if(unit.Position!=new Point2(pos[0],pos[1])||unit.GoalCell!=I(a,"goalCell"))throw new Exception("Restoration changed original pose/goal");
}
Console.WriteLine("COUNTERFACTUAL restore: original R10 verified 1000tick positions/IDs/profiles/goals exact, fresh D11 slot-exchange route caches; initial0ms+allfollowing5ms Oracle");

var methodFlags=BindingFlags.Instance|BindingFlags.NonPublic;
var future=nav.GetType().GetMethod("FutureHolderAllowsRequester",methodFlags)!;
if(!(bool)future.Invoke(nav,new[]{actorMap[6]!,actorMap[5]!})!)throw new Exception("Original5/6 future-holder positive rejected");
var counterWorld=new WorldDefinition(12,3,500,new Point2(0,0),Enumerable.Range(0,36).Select(i=>i/12==1).ToArray(),Enumerable.Range(0,36).Select(i=>i/12==1).ToArray(),new[]{12},new[]{new TargetDefinition(1,new Point2(5750,750),100)},6000);
using var counter=new Aoe4SlotExchangeFactory().Create(counterWorld,new[]{new UnitProfile(250,55,550)});
object Fake(int id,Point2 pos,int goal)
{
 var actor=Activator.CreateInstance(actorType,true)!;Set(actor,"Request",new SpawnRequest(id,new UnitProfile(250,55,550),0));Set(actor,"Position",pos);Set(actor,"Goal",goal);return actor;
}
var negativeRequester=Fake(1,new Point2(750,750),15);var negativeHolder=Fake(2,new Point2(2750,750),17);
var bodies=Array.CreateInstance(actorType,2);bodies.SetValue(negativeRequester,0);bodies.SetValue(negativeHolder,1);
var sweep=counter.GetType().GetMethod("FullBodySweep",methodFlags)!;
bool oldHolderSweep=(bool)sweep.Invoke(counter,new object[]{negativeHolder,new Point2(1750,750),bodies,-1})!;
bool oldRequesterSweep=(bool)sweep.Invoke(counter,new object[]{negativeRequester,new Point2(2750,750),bodies,2})!;
bool futureHolderAllowed=(bool)future.Invoke(counter,new[]{negativeRequester,negativeHolder})!;
if(!oldHolderSweep||!oldRequesterSweep||futureHolderAllowed)throw new Exception("Collinear future-holder negative did not reproduce");
Console.WriteLine("PURE QUERY collinear500mm corridor: old holder/requester sweeps true, future-holder predicate false; original5/6 future predicate true");
int stable=0;int completed=0;
var originalGoalSet=initial.Select(u=>u.GoalCell).OrderBy(x=>x).ToArray();
var changes=new List<object>();
for(int tick=0;tick<ticks;tick++)
{
 for(int sub=0;sub<10;sub++)
 {
  var before=nav.Snapshot().ToArray();nav.Step();var after=nav.Snapshot().ToArray();oracle.ValidateTransition(before,after,5);
  if(!after.Select(u=>u.GoalCell).OrderBy(x=>x).SequenceEqual(originalGoalSet))throw new Exception("Slot exchange changed the original goal set");
  var oldGoals=before.ToDictionary(u=>u.Id,u=>u.GoalCell);
  var changed=after.Where(u=>u.GoalCell!=oldGoals[u.Id]).Select(u=>new{u.Id,oldGoal=oldGoals[u.Id],newGoal=u.GoalCell}).ToArray();
  if(changed.Length>0)changes.Add(new{microstep=10000+tick*10+sub+1,changes=changed});
 }
 completed=tick+1;var now=nav.Snapshot();
 stable=now.All(u=>u.State!=MotionState.Moving)?stable+1:0;
 if(stable>=200)break;
}
var final=nav.Snapshot();
var result=new{scope="Diagnostic counterfactual from exact R10 verified prefix poses/IDs/profiles/goals; fresh D11 planning caches; full original world/radii/speeds, all continuation5ms oracle; not a from-spawn R10 complete-case result",ticks=completed,holdTicks=stable,oraclePairSweeps=oracle.PairSweeps,oracleBodySweeps=oracle.BodySweeps,minimumGap=oracle.MinimumBodyGapMm,initial=initial.Select(u=>new{u.Id,x=u.Position.X,y=u.Position.Y,state=u.State.ToString(),u.GoalCell}).ToArray(),final=final.Select(u=>new{u.Id,x=u.Position.X,y=u.Position.Y,state=u.State.ToString(),u.GoalCell}).ToArray(),counterExample=new{oldHolderSweep,oldRequesterSweep,futureHolderAllowed},goalChanges=changes,metrics=nav.Metrics,candidateAssemblySha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Aoe4SlotExchangeFactory).Assembly.Location))).ToLowerInvariant()};
File.WriteAllText(output,JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine($"RESTORED prefix continuation ticks{completed} hold{stable} moving{final.Count(u=>u.State==MotionState.Moving)} minGap{oracle.MinimumBodyGapMm}");
