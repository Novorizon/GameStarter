using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using NavigationLab.Core;
using NavigationLab.Oracle;

if (args.Length != 3)
{
    throw new ArgumentException("Arguments: candidate DLL, full factory type, result JSON");
}
var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var factory = (INavigationFactory)Activator.CreateInstance(assembly.GetType(args[1], true)!)!;
const int width = 16;
const int height = 12;
var walk = new bool[width * height];
for (int y = 1; y < height - 1; y++)
{
    for (int x = 1; x < width - 1; x++)
    {
        walk[y * width + x] = true;
    }
}
int oldGoal = 11 + 4 * width;
int newGoal = 12 + 4 * width;
int spawn = 2 + 4 * width;
var holding = new bool[walk.Length];
holding[oldGoal] = true;
holding[newGoal] = true;
var world = new WorldDefinition(width, height, 1000, new Point2(0, 0), walk, holding, new[] { spawn },
    new[] { new TargetDefinition(1, new Point2(10350, 4500), 300) }, 10000);
var profile = new UnitProfile(650, 1000, 300);
var request = new SpawnRequest(1, profile, spawn);
using var navigator = factory.Create(world, new[] { profile });
var oracle = new ContinuousOracle(world);
var before = navigator.Snapshot().ToArray();
if (!navigator.TrySpawn(request))
{
    throw new InvalidOperationException("Valid initial spawn rejected: " + navigator.LastSpawnFailure);
}
var current = navigator.Snapshot().ToArray();
oracle.RegisterBirth(request, before, current);
int initialStable = 0;
int initialSteps = 0;
for (; initialSteps < 10000 && initialStable < 2000; initialSteps++)
{
    navigator.Step();
    var next = navigator.Snapshot().ToArray();
    oracle.ValidateTransition(current, next, 5);
    initialStable = next.Single().State == MotionState.Attacking && next.Single().GoalCell == oldGoal
        && next.Single().Position == current.Single().Position ? initialStable + 1 : 0;
    current = next;
}
if (initialStable < 2000)
{
    throw new InvalidOperationException("Initial one-body oldGoal did not settle.");
}
var change = new WorldChange { ReplaceTarget = new TargetDefinition(1, new Point2(13650, 4500), 300) };
oracle.ValidateWorldChangeInput(change, current);
if (!navigator.ApplyWorldChange(change))
{
    throw new InvalidOperationException("Legal target move rejected.");
}
var changed = navigator.Snapshot().ToArray();
oracle.ApplyChange(change, current, changed);
current = changed;

// Independent physical witness for the same body, same new target and original Holding points.
var witnessOracle = new ContinuousOracle(oracle.World);
var witnessStart = new[] { new UnitSnapshot(1, current.Single().Position, MotionState.Moving, newGoal, 1) };
var live = (Dictionary<int, SpawnRequest>)typeof(ContinuousOracle).GetField("live", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(witnessOracle)!;
live.Add(1, request);
witnessOracle.ValidateTransition(witnessStart, witnessStart, 0);
int witnessSteps = 0;
while (Point2.Distance(witnessStart.Single().Position, world.Center(newGoal)) > .000001)
{
    Point2 delta = world.Center(newGoal) - witnessStart.Single().Position;
    Point2 point = witnessStart.Single().Position + delta.Normalized * Math.Min(delta.Length, profile.SpeedMmPerTick / 10.0);
    var next = new[] { new UnitSnapshot(1, point, MotionState.Moving, newGoal, 1) };
    witnessOracle.ValidateTransition(witnessStart, next, 5);
    witnessStart = next;
    witnessSteps++;
}
var witnessFinal = new[] { new UnitSnapshot(1, world.Center(newGoal), MotionState.Attacking, newGoal, 1) };
witnessOracle.ValidateTransition(witnessStart, witnessFinal, 0);
for (int hold = 0; hold < 2000; hold++)
{
    witnessOracle.ValidateTransition(witnessFinal, witnessFinal, 5);
}
int stable = 0;
int steps = 0;
for (; steps < 10000 && stable < 2000; steps++)
{
    navigator.Step();
    var next = navigator.Snapshot().ToArray();
    oracle.ValidateTransition(current, next, 5);
    stable = next.Single().State == MotionState.Attacking && next.Single().GoalCell == newGoal
        && next.Single().Position == current.Single().Position ? stable + 1 : 0;
    current = next;
}
var final = current.Single();
var result = new
{
    scope = "Supplementary one-r650 target move; original two Holding points1000mm apart, no other body. Not common49 input.",
    success = stable >= 2000,
    oldGoal,
    newGoal,
    radius = 650,
    speed = 1000,
    attackRange = 300,
    initialStableMicrosteps = initialStable,
    candidateAfterMove = new { final.Id, x = final.Position.X, y = final.Position.Y, final.GoalCell, state = (int)final.State, steps, stable },
    independentWitnessSuccess = true,
    independentWitnessMovementMicrosteps = witnessSteps,
    independentWitnessHoldMicrosteps = 2000,
    candidateAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant(),
    oracleBodySweeps = oracle.BodySweeps,
    metrics = navigator.Metrics
};
File.WriteAllText(args[2], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
