# D：依据《帝国时代 IV》公开架构实现的导航候选

本候选是独立 C# 实验，基线为 GameStarter `8c0dd50`。它不包含或声称恢复微软/Relic 的商业源码。

## 核实到的一手来源

- Frank Cheng（World's Edge），GDC 2022：[演讲页面](https://gdcvault.com/play/1028036/Pathing-in-Age-of-Empires)。
- [GDC 官方完整幻灯片](https://media.gdcvault.com/GDC+2022/Speaker+Slides/Pathing+In+Age_Cheng_Frank+2022-03-29+00.16.38.pdf)，本轮已实际下载并阅读，共36个PDF页。PDF页码与幻灯片编号一致到35，最后另有致谢/活动信息。

公开资料确证：地形按块抽象出连接入口，块间搜索决定流场覆盖；方向由代价积分生成，LOS区域与FMM结合；为避免单块边界质量下降，可用重叠分段计算和缓存；混合通行限制从较受限类型扩展；局部控制同时考虑移动单位、不动单位和静态小障碍。幻灯片还介绍了编队与水陆接驳，后两者不在本轮统一地面塔防模型中。

## 本候选的具体选择

下面的参数与业务策略由本项目实现，不声称是商业游戏内部值：

- 8×8逻辑格为一个块；每个边界可通行格为入口节点，块内连接代价用真实圆盘扫掠验证的八邻边与直/斜实际距离Dijkstra计算。
- 先在入口图做A*，随后在三块重叠片段中计算LOS/FMM距离及方向，按需推进；缓存按世界修订、身体半径、出口和片段覆盖区分。
- 混合体型允许以最大注册半径的合法距离值作为种子，再扩展到较小半径可走的区域。目标/片段对大体型不可达时独立计算，不捏造共享。
- 局部控制采用候选方向采样与邻居预测，连续圆盘运动由明确的物理停止规则约束；停止/冲突提案单独计数，不能靠碰撞夹紧被动宣称已到达。
- 最终驻留格、射程、排队、死亡补位和可选的显式让路属于塔防适配，不是GDC披露的攻击调度算法。基础与增强版本分别报告。

实现不调用 A 的 SIPP 或 B 的 ORCA。具体参数、功能覆盖及失败反例由统一 NavigationLab Runner 的冻结报告说明；有限测试不构成一般完备性保证。

## 复现层与原版细节的边界

官方PDF的SHA-256为 `bd2283202abc643abd7ba6e093a78fc07e89032f171cc34e8581330b7ac1512b`。未将整份受版权保护的幻灯片收入仓库。

| 披露的架构部分 | 本候选实际执行的位置 | 本项目的具体决策 |
| --- | --- | --- |
| 分块、入口图及HPA* | `HierarchicalFlow.Graph/FindRoute` | 8×8块，枚举合法边界格，块内八邻Dijkstra真实长度代价；按块内连通分量定位实际位置 |
| LOS与FMM积分 | `HierarchicalFlow.Integrate/Eikonal` | 解析圆盘扫掠判LOS，不实现原图示的影线扫描加速；双精度四邻上风解加合法对角边松弛，不复刻8位方向存储 |
| 重叠分段流与缓存 | `HierarchicalFlow.Direction` | 三块窗口及相邻叶块扩展；按出口、覆盖与半径复用，世界修改时整体失效 |
| 从受限体型扩展 | `HierarchicalFlow.Integrate` | 同片段内复用最大注册半径的可达种子，再向小体型区域积分 |
| 静/动/不动对象的局部控制 | `AoeNavigator/Steering` | 角度采样、预测、局部轮转提案；精确窄路点与连续扫掠停止，不宣称是原版公式 |

统一Core使用二值地面，本候选没有原版的加权地形/水陆接驳、完整编队虚拟领队或网络锁步工程。`MultipleTargets/DynamicTerrain/MovingTarget` 等插件能力表示本适配器实现了对应API，实际是否通过须看共同矩阵，不能仅依据标记认定正确。

## 保留的开发失败

`Evidence/Rejected` 保存实际执行过的失败输入/输出与源码历史。它们是开发诊断，不冒充最终冻结矩阵：

- 首次Forest12只生成2人：近邻预测错误地惩罚了安全远离动作；另一处路径定位把重复tile当成同一个可通分量。
- 窄路控制尝试曾在Forest44只生成7人；后续修正零长度提案竞争、已过路点回追及同帧提案相互假设，单Big及12Big才实际走通。
- r5仍有密集目标区反例：open48全出生但29人未到位，Forest44全出生但24人未到位。D1临时让路在同Forest44更差。当前独立审计在区分本项目路点/围攻控制缺陷，不将这些失败归结为《帝国时代IV》原版HPA/FMM的能力边界。

基础D0与D1额外让路分开保存。`YieldReturns` 在该开发版本是返程命令数量，不是已完成返场人数；最终到位只能由5ms独立oracle及稳定观察认定。

## 执行层修正与正式验证

r6 将精确不动身体圆盘加入私有HPA/FMM规划几何，并按身体集合变化失效缓存；它不修改输入地形或身体半径。r7 修正已验证flowExit LOS合法时格心纠偏导致的两步振荡。r8 在流方向为零、但实际位置到原最终目标的整段圆盘LOS合法时提供直达兜底。这是本项目对格心离散漏路的处理，仍受原5ms连续身体碰撞规则约束，不表示原商业游戏具有相同实现。

正式验证只使用共同冻结的NavigationLab v2输入与Oracle；开发途中中止的诊断不计PASS/FAIL。最终完整矩阵、fresh replay、所用源码与DLL哈希由本分支证据报告给出。

R10 将本项目四邻格心表示改为经过真实圆盘扫掠验证的八邻连接，解决圆形不动物体之间明明有对角通道却被四邻图判断开的情况。HPA块内Dijkstra与跨块边都使用实际直线长度，启发式同用欧氏距离；LOS/FMM保留上风积分，并补合法对角松弛和局部下降。这是本项目的合理实现选择，公开资料没有指定本候选这些离散参数。

## D11：独立的项目围攻位置交换增强

`Aoe4Factory` 保持基础D0；`Aoe4CoordinatedFactory`是此前额外让路探索；新增`Aoe4SlotExchangeFactory`显式启用本项目位置交换。它不是GDC披露的原版商业调度公式。

同完整Profile/Target、非AssignedGoal的单位长期无进展时，只有到位holder能对所有真实身体/基地/地形安全直达requester原Goal，且requester能在holder离开后接其旧Goal，才原子交换两个原合法位置。holder实际到位后requester才继续走；交换命令、holder到位、双方完成分别计数。身体、原Goal集合和人数不变，未到位仍是Moving。独立增强必须整版测试，不能按场景混选D0与D11。

## D12：独立的路线进展观察增强

`Aoe4ProgressExchangeFactory`在D11已验证的future/actual holder安全条件之上，独立启用进展观察。不是把摆动位移当作已经脱困，也不声称它自动解决所有拥堵。

剩余量使用当前LOS/FMM代价加HPA后续段代价；重新接入包含真实join段。真实Goal/临时yield/世界形状变化区分意图；实际不动物体集合与路线拓扑区分历史，同一路重试或缓存重建不清历史，新路线基线本身不算前进。每个固定2秒窗口，只有历史最优剩余量改善且实际净位移成立才确认进展；无可投影路线时另要求连续静止窗口。历史达到上限后不将未知移动轨迹误判为已观测停滞。

公开计数包括route baselines、same-intent retries、historical-best improvements、qualified windows、motion-only/potential-only rejected windows和stall detections；恢复是否成功仍以原5ms物理Oracle及全部真实到位/驻留为准。组件正负例不加入共同49计分，正式矩阵仍使用原人数/地形/半径/速度/Goal规则。

## D13：独立的静态路径深度选点策略

`Aoe4DeepGoalFactory`保留D12的恢复与观察，只改变新请求的一般选点优先级：原Holding/CanHold候选池、Attack优先资格/射程、GoalClear及配额规则完全不变，去掉outer偏好，按相对此次请求入口的真实直/斜Dijkstra静态路径代价选择深点。不接收未来人数/顺序、certificate目标或见证路线；不因新出生暗中重排已准入者Goal，Assigned请求不变。

非Assigned的前N实际预约子集可以与旧策略不同，选点始终来自原不变合法池；这属于项目slot预防策略，不是HPA本体或GDC披露商业公式的收益。整体版本按原人数、地图、体型、速度做相同四项及后续共同49验证，不按case切换版本。

## 本轮正式候选选择

统一选择`NavigationLab.DAoe4.Aoe4ProgressExchangeFactory`（D12）执行最终共同49。D0基础、D1额外让路、D11交换与D13深点策略保留为显式可选探索，不能在不同case中混选结果；D13的Forest改善及open回退均保留。阶段比较见`Evidence/D12D13KeyComparison`，最终49只认同源冻结清单、选定factory及实际完整输出；旧阶段开发PASS/FAIL不拼成最终矩阵。
