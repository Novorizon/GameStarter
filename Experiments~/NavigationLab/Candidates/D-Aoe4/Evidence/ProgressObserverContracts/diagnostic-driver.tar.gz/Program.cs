using NavigationLab.Core;
using NavigationLab.Oracle;
using NavigationLab.DAoe4;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

var output = Path.GetFullPath(args[0]);
Directory.CreateDirectory(output);
var flags = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
object? Get(object value, string name) => value.GetType().GetField(name, flags)!.GetValue(value);
void Set(object value, string name, object? item) => value.GetType().GetField(name, flags)!.SetValue(value, item);
object Call(object value, string name, params object?[] items) => value.GetType().GetMethod(name, flags)!.Invoke(value, items)!;
string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
var profile = new UnitProfile(250, 55, 550);
var negativeWorld = new WorldDefinition(24, 12, 1000, new Point2(0, 0), Enumerable.Repeat(true, 288).ToArray(),
    Enumerable.Repeat(true, 288).ToArray(), new[] { 74 }, new[] { new TargetDefinition(1, new Point2(18500, 3500), 1000) }, 10000);
using var negative = new Aoe4ProgressExchangeFactory().Create(negativeWorld, new[] { profile });
var request = new SpawnRequest(1, profile, 74);
if (!negative.TrySpawn(request))
{
    throw new Exception("Negative observer fixture birth failed.");
}
var oracle = new ContinuousOracle(negativeWorld);
oracle.RegisterBirth(request, Array.Empty<UnitSnapshot>(), negative.Snapshot());
var actor = ((System.Collections.IDictionary)Get(negative, "actors")!)[1]!;
var planner = Get(negative, "planner")!;
var observe = negative.GetType().GetMethod("ObserveRouteProgress", flags)!;
var initialGoal = negative.Snapshot()[0].GoalCell;
var previous = negative.Snapshot().ToArray();
int detectedAt = -1;
int cacheRebuilds = 0;
var hundredStepPositions = new List<Point2> { previous[0].Position };
for (int microstep = 1; microstep <= 3000; microstep++)
{
    double angle = Math.PI + microstep * Math.PI * 2 / 500;
    var position = new Point2(2800 + 300 * Math.Cos(angle), 3500 + 300 * Math.Sin(angle));
    Set(actor, "Position", position);
    Set(actor, "Velocity", position - previous[0].Position);
    Set(negative, "step", microstep);
    int cell = negativeWorld.CellAt(position);
    if (microstep % 50 == 0)
    {
        Call(planner, "Invalidate");
        var replacement = Call(planner, "FindRoute", cell, initialGoal, profile.RadiusMm);
        if (replacement == null)
        {
            throw new Exception("Negative observer route retry failed.");
        }
        Set(actor, "Route", replacement);
        cacheRebuilds++;
    }
    var route = Get(actor, "Route")!;
    object?[] directionArguments = { position, route, null };
    planner.GetType().GetMethod("Direction", flags)!.Invoke(planner, directionArguments);
    observe.Invoke(negative, new object?[] { actor, directionArguments[2], cell, false });
    var current = negative.Snapshot().ToArray();
    oracle.ValidateTransition(previous, current, 5);
    previous = current;
    if (microstep % 100 == 0)
    {
        hundredStepPositions.Add(position);
    }
    if ((bool)Get(Get(actor, "Progress")!, "Stalled")! && detectedAt < 0)
    {
        detectedAt = microstep;
    }
}
var motionOnly = negative.Metrics.TryGetValue("RouteProgressMotionOnlyWindowsRejected", out long motion) ? motion : 0;
var reused = negative.Metrics.TryGetValue("RouteProgressSameIntentRetries", out long retries) ? retries : 0;
if (detectedAt < 0 || motionOnly == 0 || reused == 0)
{
    throw new Exception("Closed oracle-valid orbit did not retain history and detect stagnation.");
}
var displacements = hundredStepPositions.Skip(1).Select((p, i) => Point2.Distance(p, hundredStepPositions[i])).ToArray();
var negativeResult = new
{
    scope = "Observer component contract only: externally prescribed closed physical trajectory, every5ms original radius/speed Oracle; not candidate-generated gameplay or a common49 case.",
    radiusMm = profile.RadiusMm,
    speedMmPerTick = profile.SpeedMmPerTick,
    orbitRadiusMm = 300,
    periodMicrosteps = 500,
    microsteps = 3000,
    detectedAt,
    cacheRebuilds,
    minimumHundredStepDisplacementMm = displacements.Min(),
    legacyQuarterRadiusThresholdMm = profile.RadiusMm * .25,
    physicalBodySweeps = oracle.BodySweeps,
    metrics = negative.Metrics,
    finalProgressStalled = Get(Get(actor, "Progress")!, "Stalled")
};
File.WriteAllText(Path.Combine(output, "closed-orbit.json"), JsonSerializer.Serialize(negativeResult, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("NEGATIVE closed orbit detected at " + detectedAt + "; motion-only windows rejected=" + motionOnly + "; same-route history reused=" + reused);

var source = "/workspace/navigation-comparison/results/d-r10-forest-single/inputs/forest-single-large.json";
using var doc = JsonDocument.Parse(File.ReadAllText(source));
var worldData = doc.RootElement.GetProperty("world");
int I(JsonElement node, string key) => node.GetProperty(key).GetInt32();
double D(JsonElement node, string key) => node.GetProperty(key).GetDouble();
var world = new WorldDefinition(I(worldData, "width"), I(worldData, "height"), I(worldData, "cellSizeMm"),
    new Point2(D(worldData.GetProperty("origin"), "x"), D(worldData.GetProperty("origin"), "y")),
    worldData.GetProperty("walkable").GetString()!.Select(c => c == '1').ToArray(),
    worldData.GetProperty("holding").GetString()!.Select(c => c == '1').ToArray(),
    worldData.GetProperty("spawnCells").EnumerateArray().Select(n => n.GetInt32()).ToArray(),
    worldData.GetProperty("targets").EnumerateArray().Select(n => new TargetDefinition(I(n, "id"), new Point2(D(n, "x"), D(n, "y")), I(n, "radiusMm"))).ToArray(),
    I(worldData, "gatheringDistanceMm"));
var first = doc.RootElement.GetProperty("requests").EnumerateArray().OrderBy(n => Math.Abs(world.Center(I(n, "spawnCell")).Y - world.Target(I(n, "targetId")).Center.Y)).First();
var positiveProfile = new UnitProfile(I(first, "radiusMm"), I(first, "speedMmPerTick"), I(first, "attackRangeMm"));
var positiveRequest = new SpawnRequest(I(first, "id"), positiveProfile, I(first, "spawnCell"), I(first, "targetId"), I(first, "assignedGoalCell"));
using var positive = new Aoe4ProgressExchangeFactory().Create(world, new[] { positiveProfile });
if (!positive.TrySpawn(positiveRequest))
{
    throw new Exception("Original Forest single-agent observer fixture birth failed.");
}
var positiveOracle = new ContinuousOracle(world);
positiveOracle.RegisterBirth(positiveRequest, Array.Empty<UnitSnapshot>(), positive.Snapshot());
var positiveActor = ((System.Collections.IDictionary)Get(positive, "actors")!)[positiveRequest.Id]!;
int awayProgressSamples = 0;
int stable = 0;
int done = 0;
double lastEuclidean = double.PositiveInfinity;
double lastRemaining = double.PositiveInfinity;
for (int microstep = 1; microstep <= 30000; microstep++)
{
    var before = positive.Snapshot().ToArray();
    double euclidean = Point2.Distance(before[0].Position, world.Center(before[0].GoalCell));
    positive.Step();
    var after = positive.Snapshot().ToArray();
    positiveOracle.ValidateTransition(before, after, 5);
    var progress = Get(positiveActor, "Progress");
    if (progress != null)
    {
        double remaining = (double)Get(progress, "LastRemaining")!;
        if (euclidean > lastEuclidean + .001 && remaining < lastRemaining - .001)
        {
            awayProgressSamples++;
        }
        lastEuclidean = euclidean;
        lastRemaining = remaining;
    }
    stable = after[0].State == MotionState.Moving ? 0 : stable + 1;
    done = microstep;
    if (stable >= 2000)
    {
        break;
    }
}
long stalls = positive.Metrics.TryGetValue("RouteProgressStallDetections", out long count) ? count : 0;
if (stable < 2000 || awayProgressSamples == 0 || stalls != 0)
{
    throw new Exception("Original Forest detour observer did not demonstrate valid away-from-goal progress without false stall: away=" + awayProgressSamples + ", stalls=" + stalls);
}
var positiveResult = new
{
    scope = "Single-agent observer diagnostic using unchanged original forest-single-large complete input/profile/request/population; independent5ms Oracle and actual generated route; not a replacement for the strict full49 Runner report.",
    originalInputSha256 = Hash(source),
    originalPopulation = doc.RootElement.GetProperty("requests").GetArrayLength(),
    diagnosticPopulation = 1,
    microsteps = done,
    stableMicrosteps = stable,
    awayProgressSamples,
    stalls,
    physicalBodySweeps = positiveOracle.BodySweeps,
    metrics = positive.Metrics,
    final = positive.Snapshot().Select(u => new { u.Id, u.GoalCell, x = u.Position.X, y = u.Position.Y, state = u.State.ToString() }).ToArray()
};
File.WriteAllText(Path.Combine(output, "forest-detour-single-agent.json"), JsonSerializer.Serialize(positiveResult, new JsonSerializerOptions { WriteIndented = true }));
File.WriteAllText(Path.Combine(output, "manifest.json"), JsonSerializer.Serialize(new { candidateAssemblySha256 = Hash(typeof(Aoe4ProgressExchangeFactory).Assembly.Location), sourceSha256 = Hash(Path.Combine(AppContext.BaseDirectory, "../../../Program.cs")), scope = "Observer component contracts only; not common49 score." }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("POSITIVE Forest detour away-progress=" + awayProgressSamples + ", stalls=" + stalls + ", stableMicrosteps=" + stable);
