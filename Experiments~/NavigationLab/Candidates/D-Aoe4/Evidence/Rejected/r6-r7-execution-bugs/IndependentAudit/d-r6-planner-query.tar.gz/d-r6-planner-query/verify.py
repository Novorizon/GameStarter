import gzip
import hashlib
import json
import math
from pathlib import Path

root = Path('/workspace/navigation-comparison')
source = root / 'results/d-r6-open'
report_path = source / 'open-arena.json'
input_path = source / 'inputs/open-arena.json'
trace_path = source / 'traces/open-arena.jsonl.gz'
report = json.loads(report_path.read_bytes())
original = json.loads(input_path.read_bytes())
world = original['world']
profiles = {request['id']: request for request in original['requests']}
bodies = []
for item in report['FinalState'].split('|'):
    identity, coordinate, state, goal, target = item.split(':')
    x, y = map(float, coordinate.split(','))
    bodies.append({'id': int(identity), 'position': [x, y], 'state': int(state), 'goal': int(goal)})
actor = next(body for body in bodies if body['id'] == 28)
a = actor['position']
cell = actor['goal']
size = world['cellSizeMm']
b = [world['origin']['x'] + (cell % world['width'] + .5) * size,
     world['origin']['y'] + (cell // world['width'] + .5) * size]

def segment_distance(point, start, end):
    vx, vy = end[0] - start[0], end[1] - start[1]
    squared = vx * vx + vy * vy
    fraction = max(0, min(1, ((point[0] - start[0]) * vx + (point[1] - start[1]) * vy) / squared)) if squared else 0
    return math.hypot(start[0] + fraction * vx - point[0], start[1] + fraction * vy - point[1])

radius = profiles[28]['radiusMm']
checks = [{'kind': 'body', 'id': other['id'],
           'gapMm': segment_distance(other['position'], a, b) - radius - profiles[other['id']]['radiusMm']}
          for other in bodies if other['id'] != 28]
checks += [{'kind': 'base', 'id': target['id'],
            'gapMm': segment_distance([target['x'], target['y']], a, b) - radius - target['radiusMm']}
           for target in world['targets']]
left, bottom = world['origin']['x'], world['origin']['y']
checks.append({'kind': 'world-boundary', 'gapMm': min(min(a[0], b[0]) - left, min(a[1], b[1]) - bottom,
               left + world['width'] * size - max(a[0], b[0]), bottom + world['height'] * size - max(a[1], b[1])) - radius})
# Every closed rectangle lies outside the entire swept disc AABB, an exact conservative disjointness certificate.
nearby = []
for cell, walkable in enumerate(world['walkable']):
    if walkable == '1':
        continue
    x, y = left + cell % world['width'] * size, bottom + cell // world['width'] * size
    disjoint = x + size < min(a[0], b[0]) - radius or x > max(a[0], b[0]) + radius or y + size < min(a[1], b[1]) - radius or y > max(a[1], b[1]) + radius
    if not disjoint:
        nearby.append(cell)
assert not nearby, nearby
assert min(check['gapMm'] for check in checks) > 207

points = [(24500., 19500.), (24570.710678118656, 19570.710678118656)]
tail_count = updates = 0
last_index = None
start_step = end_step = None
with gzip.open(trace_path, 'rt') as stream:
    for line in stream:
        frame = json.loads(line)
        for unit in frame.get('changed', []):
            if unit[0] != 28:
                continue
            updates += 1
            point = (unit[1], unit[2])
            index = points.index(point) if point in points else None
            compatible = index is not None and unit[3:] == [0, 645, 1]
            if compatible:
                if last_index is not None and index != last_index:
                    tail_count += 1
                else:
                    tail_count = 1
                    start_step = frame['step']
                last_index = index
                end_step = frame['step']
            else:
                tail_count = 0
                last_index = None
                start_step = end_step = None
assert tail_count > 100000
output = {'scope': 'Read-only audit of the original r6 failure. Geometric witness fixes all other 47 original bodies; no candidate result is changed.',
          'actorId': 28, 'from': a, 'unchangedGoalCell': actor['goal'], 'to': b,
          'continuousChecks': checks, 'minimumGapMm': min(check['gapMm'] for check in checks),
          'closedCellsAllDisjointFromSweptAabb': True, 'microstepsOf5MsAtOriginalSpeedLimit': math.ceil(math.dist(a, b) / (profiles[28]['speedMmPerTick'] / 10)),
          'traceActorChangedRecords': updates,
          'alternatingTraceTail': {'changedRecords': tail_count, 'startStep': start_step, 'endStep': end_step,
                                   'points': points, 'state': 'Moving', 'goalCell': 645}}
output_path = Path(__file__).with_name('geometry-and-trace.json')
output_path.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({key: value for key, value in output.items() if key != 'continuousChecks'}, indent=2))
