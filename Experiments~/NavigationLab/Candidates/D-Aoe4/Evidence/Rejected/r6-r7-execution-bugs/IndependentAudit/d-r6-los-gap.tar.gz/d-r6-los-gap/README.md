# D r6 actor 3: continuous LOS lost by the grid representation

This read-only diagnostic uses the original R6 `open-arena` failure and the exact frozen candidate DLL `78d2c59e28054c706bece624745c22510697981feacaff385c98039849651544` (commit `6893310fa6cff2ddf41234b1800eddb1d5ce0b5c`). It does not modify any candidate, physical body, original goal, world, speed, result, or request order.

Actor 3 is at `(22538.404586116125,14359.800276478762)`. Its unchanged goal is cell 427 `(24500,13500)`. Holding every other original body fixed, the complete straight swept-disc segment is valid, with minimum physical gap **14.288297899 mm** (body 6 is closest at the start). All closed rectangles are disjoint from the entire swept-disc AABB, and all base/world exclusions are clear. The segment can be subdivided into 22 steps of 5 ms without exceeding the original speed cap. This is an existence witness at the reported endpoint, not a candidate execution pass.

However, the grid centre of the actor's current cell 456 has no available cardinal neighbour: 455 is occupied by settled body 9, 457 overlaps the base exclusion, 425 is occupied by settled body 8, and 487 overlaps the base exclusion. A four-neighbour centre graph therefore loses the real diagonal escape from this cell.

`Program.cs` reconstructs only the R6 planner, using the exact 37 final settled circles and the copied frozen Core/candidate binaries. The actual candidate's `GridGeometry.CanSegment(current, finalGoal, radius250)` returns **true**, while `HierarchicalFlow.FindRoute(456,427,250)` returns **null**, giving no field and a zero direction. This is a reproducible representation gap rather than evidence of physical impossibility. It is not a full internal battle-state restore or full replay.

A conservative project adaptation is to try a geometrically valid current-to-final-goal LOS when the grid planner provides no direction, while retaining the original actual-body collision checks. That does not require changing the map, radius, speed, or goal, and is not attributed to proprietary AoE4 source or claimed to solve every crowded scene. Actor 6 shares cell 456, but its current direct path is actually blocked by actor 3, so the certificate intentionally makes no equivalent direct-path claim for actor 6.

`verify.py` produces the independent geometric and neighbour certificate. `planner.log` records the actual frozen-DLL query. `manifest.json` binds all sources, reports and copied binaries; original large traces are not copied.
