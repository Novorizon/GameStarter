import gzip
import hashlib
import json
import math
from pathlib import Path

root = Path('/workspace/navigation-comparison')
source = root / 'results/d-r6-open'
report_path = source / 'open-arena.json'
input_path = source / 'inputs/open-arena.json'
trace_path = source / 'traces/open-arena.jsonl.gz'
report = json.loads(report_path.read_bytes())
original = json.loads(input_path.read_bytes())
world = original['world']
profiles = {request['id']: request for request in original['requests']}
bodies = []
for item in report['FinalState'].split('|'):
    identity, coordinate, state, goal, target = item.split(':')
    x, y = map(float, coordinate.split(','))
    bodies.append({'id': int(identity), 'position': [x, y], 'state': int(state), 'goal': int(goal)})
actor = next(body for body in bodies if body['id'] == 3)
a = actor['position']
cell = actor['goal']
size = world['cellSizeMm']
b = [world['origin']['x'] + (cell % world['width'] + .5) * size,
     world['origin']['y'] + (cell // world['width'] + .5) * size]

def segment_distance(point, start, end):
    vx, vy = end[0] - start[0], end[1] - start[1]
    squared = vx * vx + vy * vy
    fraction = max(0, min(1, ((point[0] - start[0]) * vx + (point[1] - start[1]) * vy) / squared)) if squared else 0
    return math.hypot(start[0] + fraction * vx - point[0], start[1] + fraction * vy - point[1])

radius = profiles[3]['radiusMm']
checks = [{'kind': 'body', 'id': other['id'],
           'gapMm': segment_distance(other['position'], a, b) - radius - profiles[other['id']]['radiusMm']}
          for other in bodies if other['id'] != 3]
checks += [{'kind': 'base', 'id': target['id'],
            'gapMm': segment_distance([target['x'], target['y']], a, b) - radius - target['radiusMm']}
           for target in world['targets']]
left, bottom = world['origin']['x'], world['origin']['y']
checks.append({'kind': 'world-boundary', 'gapMm': min(min(a[0], b[0]) - left, min(a[1], b[1]) - bottom,
               left + world['width'] * size - max(a[0], b[0]), bottom + world['height'] * size - max(a[1], b[1])) - radius})
# Every closed rectangle lies outside the entire swept disc AABB, an exact conservative disjointness certificate.
nearby = []
for cell, walkable in enumerate(world['walkable']):
    if walkable == '1':
        continue
    x, y = left + cell % world['width'] * size, bottom + cell // world['width'] * size
    disjoint = x + size < min(a[0], b[0]) - radius or x > max(a[0], b[0]) + radius or y + size < min(a[1], b[1]) - radius or y > max(a[1], b[1]) + radius
    if not disjoint:
        nearby.append(cell)
assert not nearby, nearby
assert min(check['gapMm'] for check in checks) > 14


fixed = [body for body in bodies if body['state'] != 0]
source_cell = int((a[1] - bottom) // size) * world['width'] + int((a[0] - left) // size)
neighbors = []
for delta in [-1, 1, -world['width'], world['width']]:
    neighbor = source_cell + delta
    point = [left + (neighbor % world['width'] + .5) * size, bottom + (neighbor // world['width'] + .5) * size]
    blockers = []
    for other in fixed:
        if math.dist(point, other['position']) < radius + profiles[other['id']]['radiusMm']:
            blockers.append('settled body ' + str(other['id']))
    for target in world['targets']:
        if math.dist(point, [target['x'], target['y']]) < radius + target['radiusMm']:
            blockers.append('base ' + str(target['id']))
    assert blockers
    neighbors.append({'cell': neighbor, 'center': point, 'blockers': blockers})
output = {'scope': 'Original r6 actor 3 has a legal continuous straight path to its unchanged goal with all other bodies fixed, while its four-neighbour grid centre is isolated. This is a representation-gap diagnostic, not a candidate pass.',
          'actorId': 3, 'from': a, 'sourceCell': source_cell, 'goalCell': actor['goal'], 'to': b,
          'minimumContinuousBodyBaseBoundaryGapMm': min(check['gapMm'] for check in checks),
          'continuousChecks': checks, 'closedCellsDisjointFromSweptDiscAabb': True, 'fourNeighbors': neighbors,
          'microstepsOf5MsAtOriginalSpeedLimit': math.ceil(math.dist(a, b) / (profiles[3]['speedMmPerTick'] / 10))}
Path(__file__).with_name('geometry.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({key: value for key, value in output.items() if key != 'continuousChecks'}, indent=2))
