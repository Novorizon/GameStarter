# D r6 actor 28: verified execution oscillation

This is a read-only diagnostic of the original `d-r6-open/open-arena.json` failure. No candidate source, input, goal, body, speed, admission order, or original result was changed. R6 is commit `6893310fa6cff2ddf41234b1800eddb1d5ce0b5c`, candidate DLL SHA-256 `78d2c59e28054c706bece624745c22510697981feacaff385c98039849651544`.

## Findings

Actor 28's unchanged goal is cell 645 `(25500,20500)`. The original complete trace shows **119551 consecutive changed frames**, steps 451 through 120001 inclusive, alternating every 5 ms between `(24500,19500)` and `(24570.710678118656,19570.710678118656)`. Its state remains Moving and its goal remains 645. This is a persistent two-step oscillation, not an inference from a motionless endpoint.

At the original final state, actor 28 can reach that goal along a single 1414.214 mm straight segment while **all 47 other physical bodies remain fixed**. The analytical minimum circle-to-segment body gap is **207.106781 mm**, every target-circle exclusion is clear, and every closed terrain cell is disjoint from the entire swept-disc AABB. Subdivision into 15 steps of 5 ms respects the original 1000 mm/50 ms speed limit. This is a conditional existence witness at the reported final state, not a candidate pass or a complete alternative navigation solution.

A separate query loads the exact R6 candidate DLL and reconstructs its planner using the 37 final settled circles. `FindRoute(613,645,250)` returns a route; source and goal are both included, their field distances are 1414.214 mm and 0, and the actual field direction is `(0.70710678,0.70710678)`. This query does not restore the original actor's internal fields and is not described as a full simulation replay.

The exact 1000-tick diagnostic prefix supplied by the candidate author records actor 28 taking the forward diagonal step, with waypoint -1, correct goal/exit 645, and proposal and executed motion `(70.710678,70.710678)`. That prefix was checked per ID against the original R6 trace endpoint; the original run already used the independent continuous oracle.

The source explains the reverse step: after the valid LOS diagonal moves the actor off the cell centre, `NearStaticCorner` finds no descending cardinal neighbour (the east/north centres contain settled units), then falls back to the current cell centre. At the centre the fallback is skipped and LOS takes another forward step. The correction controller and the valid flow direction therefore undo each other.

This is an implementation defect in the experimental controller. It must not be reported as proof that the commercial AoE4 pathfinding architecture cannot solve the scene. The candidate author preserved R6 and is testing a separate R7 change that gives a geometrically valid direct flow-exit segment priority over centre correction.

## Files

- `Program.cs`, `Query.csproj`, `execution.log`: exact-DLL pure planner query.
- `verify.py`, `geometry-and-trace.json`, `verification.log`: independent analytical straight-segment witness and original trace inspection.
- `r6-prefix-raw.json`: preserved copy of the author's diagnostic prefix.
- `manifest.json`: hashes of these files, original input/result/trace, and the actually loaded copied Core/candidate DLLs. No large trace copy is made.
